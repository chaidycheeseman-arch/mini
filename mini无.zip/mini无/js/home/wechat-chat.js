﻿// Auto-split from js/home/home-and-novel.js (139-1951)

    // ====== 聊天窗口核心逻辑 (全局作用域) ======
    let activeChatContact = null;
    // 线上/线下记忆互通：读取线下消息作为跨模式上下文
    const crossModeOfflineDb = new Dexie('miniPhoneOfflineDB');
    crossModeOfflineDb.version(1).stores({ messages: '++id, contactId, sender, content, timestamp' });
    // ====== 角色隔离锁：防止多角色并发串台 ======
    // 每次 triggerRoleReply / appendRoleMessage 都只认锁定时刻的联系人，
    // 绝不使用全局 activeChatContact 进行消息写入或UI渲染，彻底杜绝串台。
    let currentLongPressMsgId = null;
    // 横幅通知控制函数
    let notifTimer = null;
    // 修改：新增 contactId 参数用于点击跳转
    // 通知队列：支持多条消息依次显示，每条显示2秒后自动切换到下一条
    let _notifQueue = [];
    let _notifPlaying = false;
    const DEFAULT_AVATAR_DATA_URI = 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96">' +
        '<defs><linearGradient id="mini-avatar-gradient" x1="0%" y1="0%" x2="100%" y2="100%">' +
        '<stop offset="0%" stop-color="#edf2f7"/><stop offset="100%" stop-color="#d9e2ec"/>' +
        '</linearGradient></defs>' +
        '<rect width="96" height="96" rx="28" fill="url(#mini-avatar-gradient)"/>' +
        '<circle cx="48" cy="35" r="18" fill="#b9c4d0"/>' +
        '<path d="M20 84c4-16 16-24 28-24s24 8 28 24" fill="#b9c4d0"/>' +
        '</svg>'
    );

    function getSafeAvatarSrc(raw) {
        if (typeof raw === 'string' && raw.trim()) return raw.trim();
        return DEFAULT_AVATAR_DATA_URI;
    }

    function applySafeImageSource(img, raw) {
        if (!img) return;
        img.onerror = function() {
            this.onerror = null;
            this.src = DEFAULT_AVATAR_DATA_URI;
        };
        img.src = getSafeAvatarSrc(raw);
    }

    function syncWechatOverlayStack(visiblePageIds) {
        const visibleSet = new Set((Array.isArray(visiblePageIds) ? visiblePageIds : []).map(id => String(id || '')).filter(Boolean));
        if (!visibleSet.has('wechat-app')) visibleSet.add('wechat-app');
        document.querySelectorAll('.full-app-page').forEach(page => {
            if (!page || !page.id) return;
            page.style.display = visibleSet.has(page.id) ? 'flex' : 'none';
        });
        const menuPanel = document.getElementById('menu-panel');
        if (menuPanel) menuPanel.style.display = 'none';
    }

    function orderMiniChatMessages(messages) {
        return (Array.isArray(messages) ? messages : []).slice().sort(function(a, b) {
            var aId = parseInt(a && a.id, 10);
            var bId = parseInt(b && b.id, 10);
            if (isFinite(aId) && isFinite(bId) && aId !== bId) return aId - bId;
            var aTs = Number(a && a.timestamp) || 0;
            var bTs = Number(b && b.timestamp) || 0;
            if (aTs !== bTs) return aTs - bTs;
            return 0;
        });
    }

    window.getSafeAvatarSrc = getSafeAvatarSrc;
    window.applySafeImageSource = applySafeImageSource;
    window.syncWechatOverlayStack = syncWechatOverlayStack;
    window.defaultAvatarDataUri = DEFAULT_AVATAR_DATA_URI;

    function _normalizeNotifPayload(avatar, name, message, timeStr, contactId, sourceOrOptions) {
        const options = (sourceOrOptions && typeof sourceOrOptions === 'object') ? sourceOrOptions : {};
        const source = options.source || (typeof sourceOrOptions === 'string' ? sourceOrOptions : 'wechat');
        return {
            avatar: getSafeAvatarSrc(avatar || 'icon-192.png'),
            name: name || (source === 'sms' ? '信息' : 'WeChat'),
            message: message || '',
            timeStr: timeStr || '',
            contactId: options.contactId != null ? options.contactId : contactId,
            source: source === 'sms' ? 'sms' : 'wechat'
        };
    }
    function _playNotifQueue() {
        if (_notifPlaying || _notifQueue.length === 0) return;
        _notifPlaying = true;
        const { avatar, name, message, timeStr, contactId, source } = _notifQueue.shift();
        const banner = document.getElementById('notification-banner');
        const chip = document.getElementById('notif-app-chip');
        applySafeImageSource(document.getElementById('notif-avatar-img'), avatar);
        document.getElementById('notif-name-text').textContent = name;
        document.getElementById('notif-msg-text').textContent = message;
        document.getElementById('notif-time-text').textContent = timeStr;
        if (chip) chip.textContent = source === 'sms' ? '信息' : 'WeChat';
        banner.setAttribute('data-source', source || 'wechat');
        banner.setAttribute('data-contact-id', contactId ? String(contactId) : '');
        banner.classList.add('show');
        if (notifTimer) clearTimeout(notifTimer);
        notifTimer = setTimeout(() => {
            banner.classList.remove('show');
            _notifPlaying = false;
            if (_notifQueue.length > 0) {
                // 短暂间隔后显示下一条
                setTimeout(_playNotifQueue, 400);
            }
        }, 2000);
    }
    function showNotificationBanner(avatar, name, message, timeStr, contactId, sourceOrOptions) {
        // 将通知加入队列，依次播放，确保每条消息都能被看到
        _notifQueue.push(_normalizeNotifPayload(avatar, name, message, timeStr, contactId, sourceOrOptions));
        _playNotifQueue();
    }
    // 新增：横幅点击与向上滑动关闭事件监听
    document.addEventListener('DOMContentLoaded', () => {
        const banner = document.getElementById('notification-banner');
        let bannerStartY = 0;
        // 辅助：关闭当前横幅并继续播放队列
        function _dismissBannerAndContinue() {
            banner.classList.remove('show');
            if (notifTimer) { clearTimeout(notifTimer); notifTimer = null; }
            _notifPlaying = false;
            // 继续播放队列中剩余的通知
            if (_notifQueue.length > 0) {
                setTimeout(_playNotifQueue, 400);
            }
        }
        // 点击横幅进入聊天
        banner.addEventListener('click', async () => {
            const contactId = banner.getAttribute('data-contact-id');
            const source = banner.getAttribute('data-source') || 'wechat';
            try {
                if (contactId) {
                    if (source === 'sms' && typeof window.openSmsConversation === 'function') {
                        await window.openSmsConversation(contactId);
                    } else {
                        document.getElementById('wechat-app').style.display = 'flex';
                        enterChatWindow(contactId);
                    }
                } else if (source === 'sms' && typeof window.openSmsApp === 'function') {
                    window.openSmsApp();
                }
            } finally {
                _dismissBannerAndContinue();
            }
        });
        // 向上滑动关闭
        banner.addEventListener('touchstart', (e) => {
            bannerStartY = e.touches[0].clientY;
        }, {passive: true});
        banner.addEventListener('touchmove', (e) => {
            const currentY = e.touches[0].clientY;
            if (bannerStartY - currentY > 15) { // 向上滑动超过 15px 立即关闭
                _dismissBannerAndContinue();
            }
        }, {passive: true});
    });
    let currentLongPressMsgSender = null;
    let currentQuoteMsgId = null;
    let multiSelectMode = false;
    let selectedMsgIds = new Set();
    let longPressTimer = null;
    const MINI_PROTOCOL_VERSION = 'mini.chat.v2';
    const MINI_STRUCTURED_TYPES = new Set([
        'voice_message', 'red_packet', 'transfer', 'gift_delivery',
        'takeout_delivery', 'call_invite', 'forward_bundle'
    ]);

    function _miniSafeText(value, fallback) {
        if (value === undefined || value === null) return fallback || '';
        return String(value).trim();
    }

    function _miniPickText() {
        for (let i = 0; i < arguments.length; i++) {
            if (arguments[i] === undefined || arguments[i] === null) continue;
            const text = String(arguments[i]).trim();
            if (text) return text;
        }
        return '';
    }

    function getMiniProfileNickname(fallback) {
        const meNameEl = document.getElementById('text-wechat-me-name');
        const momentsNickEl = document.getElementById('text-wechat-nick');
        return _miniPickText(
            meNameEl && meNameEl.textContent,
            momentsNickEl && momentsNickEl.textContent,
            fallback,
            '我'
        );
    }

    function _miniShortText(value, maxLen) {
        const text = _miniSafeText(value, '');
        if (!text) return '';
        if (!maxLen || text.length <= maxLen) return text;
        return text.slice(0, Math.max(1, maxLen - 1)) + '…';
    }

    function _formatBeautifyPreviewClock(ts) {
        const d = ts instanceof Date ? ts : new Date(ts || Date.now());
        return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
    }

    function _getThemeModeLabel() {
        const mode = document.documentElement.getAttribute('data-theme') || 'day';
        if (mode === 'night') return '夜间模式';
        if (mode === 'custom') return '个性主题';
        if (mode === 'dopamine') return '多巴胺主题';
        return '日间模式';
    }

    function _isUsableBeautifyImage(src) {
        const value = _miniSafeText(src, '');
        if (!value) return false;
        if (value.indexOf('AQABAIAAAAAAAP///') !== -1) return false;
        if (value.indexOf('via.placeholder.com/300x600?text=Wallpaper') !== -1) return false;
        return true;
    }

    function _getWechatProfileAvatarSrc() {
        const selectors = ['#wechat-avatar-big img', '#wechat-avatar-sq img'];
        for (let i = 0; i < selectors.length; i++) {
            const img = document.querySelector(selectors[i]);
            if (img && _isUsableBeautifyImage(img.getAttribute('src') || img.src)) {
                return img.getAttribute('src') || img.src;
            }
        }
        return DEFAULT_AVATAR_DATA_URI;
    }

    const CHAT_BEAUTIFY_STORAGE_KEY = 'mini_wechat_chat_beautify_v1';
    const CHAT_BEAUTIFY_ROLE_STORAGE_PREFIX = 'mini_wechat_chat_beautify_role_v1:';
    const CHAT_BEAUTIFY_CUSTOM_STYLE_IDS = Object.freeze({
        bubble: 'mini-chat-bubble-custom-style',
        global: 'mini-chat-global-custom-style'
    });
    const CHAT_BEAUTIFY_BUBBLE_ROOTS = Object.freeze([
        '#chat-window',
        '#wechat-chat-beautify-page-preview',
        '#role-chat-beautify-page-preview',
        '#theme-chat-beautify-preview',
        '#wechat-me-beautify-preview',
        '#wechat-forward-detail-body',
        '#wechat-favorite-detail-body'
    ]);
    const CHAT_BEAUTIFY_GLOBAL_ROOTS = Object.freeze([
        '#chat-window',
        '#wechat-chat-beautify-page-preview',
        '#role-chat-beautify-page-preview',
        '#wechat-forward-detail-page',
        '#wechat-favorite-detail-page',
        '#theme-chat-beautify-preview',
        '#wechat-me-beautify-preview'
    ]);
    const CHAT_BUBBLE_CSS_TEMPLATE = [
        '/* 气泡 CSS：一个消息项 = 头像 + 气泡/特殊消息 + 时间戳 */',
        '',
        '.chat-msg-row {',
        '    gap: 8px;',
        '    padding: 0 4px;',
        '}',
        '',
        '.msg-bubble-wrapper {',
        '    max-width: 74%;',
        '    gap: 4px;',
        '}',
        '',
        '.chat-msg-avatar {',
        '    width: 36px;',
        '    height: 36px;',
        '    border-radius: 14px;',
        '    box-shadow: 0 8px 18px rgba(15,23,42,0.12);',
        '}',
        '',
        '.chat-msg-content {',
        '    border-radius: 18px;',
        '    padding: 8px 13px;',
        '    box-shadow: 0 10px 20px rgba(15,23,42,0.08);',
        '}',
        '',
        '.chat-timestamp {',
        '    margin-top: 4px;',
        '    font-size: 10px;',
        '    color: rgba(71,85,105,0.76);',
        '}',
        '',
        '.msg-quote-ref {',
        '    border-radius: 10px;',
        '}',
        '',
        '/* 所有特殊消息 */',
        '.chat-photo-card,',
        '.chat-location-card,',
        '.voice-msg-container,',
        '.chat-special-card,',
        '.chat-red-packet-card,',
        '.chat-transfer-card {',
        '    border-radius: 20px;',
        '    box-shadow: 0 12px 24px rgba(15,23,42,0.10);',
        '}',
        '',
        '/* 转发聊天记录详情里的头像 / 气泡 / 时间戳 */',
        '.wechat-record-detail-row .chat-msg-avatar {',
        '    width: 32px;',
        '    height: 32px;',
        '}',
        '',
        '.wechat-record-detail-row .chat-msg-content {',
        '    border-radius: 16px;',
        '}',
        '',
        '.wechat-record-detail-row .chat-timestamp {',
        '    font-size: 10px;',
        '}'
    ].join('\n');
    const CHAT_GLOBAL_CSS_TEMPLATE = [
        '/* 全局 CSS：覆盖线上聊天页容器、顶部、消息区、输入区、磨砂预览框 */',
        '',
        '.app-header {',
        '    background: transparent;',
        '    border-bottom: none;',
        '}',
        '',
        '.app-title {',
        '    color: #1f2937;',
        '}',
        '',
        '.chat-body {',
        '    background: linear-gradient(180deg, #f8fafc 0%, #eef2f7 100%);',
        '    padding: 14px 12px 112px;',
        '}',
        '',
        '.chat-footer {',
        '    background: rgba(255,255,255,0.88);',
        '    border-radius: 26px;',
        '    border: 1px solid rgba(255,255,255,0.9);',
        '}',
        '',
        '.chat-input-field {',
        '    color: #1f2937;',
        '}',
        '',
        '.chat-ext-panel {',
        '    border-radius: 26px 26px 0 0;',
        '}',
        '',
        '.chat-skin-preview-display {',
        '    border-radius: 28px;',
        '}',
        '',
        '.chat-skin-preview-live-shell {',
        '    background: rgba(255,255,255,0.14);',
        '}',
        '',
        '.wechat-record-detail-card {',
        '    border-radius: 24px;',
        '}'
    ].join('\n');
    const DEFAULT_CHAT_BEAUTIFY = Object.freeze({
        bubbleMe: '#e2e2e2',
        textMe: '#333333',
        bubbleOther: '#ffffff',
        textOther: '#222222',
        bubbleStyle: 'wechat',
        avatarShape: 'circle',
        avatarVisibility: 'all',
        avatarFrame: '',
        avatarFrameScale: 1.35,
        avatarFrameOffsetX: 0,
        avatarFrameOffsetY: 0,
        timeVisibility: 'both',
        readVisibility: 'none',
        bubbleCss: '',
        globalCss: ''
    });
    let currentChatBeautifyConfig = Object.assign({}, DEFAULT_CHAT_BEAUTIFY);
    let currentChatBeautifyScope = { kind: 'global', contactId: '' };
    let chatBeautifyLoaded = false;
    let chatBeautifyLoadedScopeKey = '';
    let chatBeautifyGlobalLoaded = false;
    let cachedGlobalChatBeautifyConfig = Object.assign({}, DEFAULT_CHAT_BEAUTIFY);
    let cachedRoleChatBeautifyConfigs = Object.create(null);
    let chatBeautifySaveTimer = 0;

    function _normalizeChatBeautifyColor(value, fallback) {
        const raw = _miniSafeText(value, '').toLowerCase();
        return /^#[0-9a-f]{6}$/.test(raw) ? raw : fallback;
    }

    function _normalizeChatBeautifyChoice(value, allowed, fallback) {
        const raw = _miniSafeText(value, '');
        return allowed.indexOf(raw) >= 0 ? raw : fallback;
    }

    function _normalizeChatBeautifyNumber(value, min, max, fallback) {
        const num = parseInt(value, 10);
        if (!isFinite(num)) return fallback;
        return Math.max(min, Math.min(max, num));
    }

    function _normalizeChatBeautifyFloat(value, min, max, fallback) {
        const num = parseFloat(value);
        if (!isFinite(num)) return fallback;
        const clamped = Math.max(min, Math.min(max, num));
        return Math.round(clamped * 100) / 100;
    }

    function _normalizeChatBeautifyScope(scope) {
        const source = scope && typeof scope === 'object' ? scope : {};
        const contactId = source.contactId === undefined || source.contactId === null
            ? ''
            : String(source.contactId).trim();
        if (source.kind === 'role' && contactId) {
            return { kind: 'role', contactId: contactId };
        }
        return { kind: 'global', contactId: '' };
    }

    function _isRoleChatBeautifyScope(scope) {
        const normalized = _normalizeChatBeautifyScope(scope);
        return normalized.kind === 'role' && !!normalized.contactId;
    }

    function _getChatBeautifyScopeKey(scope) {
        const normalized = _normalizeChatBeautifyScope(scope);
        return normalized.kind === 'role'
            ? ('role:' + normalized.contactId)
            : 'global';
    }

    function _getChatBeautifyRoleStorageKey(contactId) {
        const normalizedId = contactId === undefined || contactId === null ? '' : String(contactId).trim();
        return CHAT_BEAUTIFY_ROLE_STORAGE_PREFIX + normalizedId;
    }

    function _normalizeChatBeautifyCssText(value) {
        return typeof value === 'string'
            ? value.replace(/\r\n?/g, '\n').trim()
            : '';
    }

    function _normalizeChatBeautifyConfig(raw) {
        const source = raw && typeof raw === 'object' ? raw : {};
        const avatarVisibility = _normalizeChatBeautifyChoice(
            source.avatarVisibility,
            ['all', 'hide-me', 'hide-peer', 'hide-both'],
            DEFAULT_CHAT_BEAUTIFY.avatarVisibility
        );
        const timeVisibility = _normalizeChatBeautifyChoice(
            source.timeVisibility,
            ['none', 'me', 'peer', 'both'],
            source.showTimestamp === false ? 'none' : DEFAULT_CHAT_BEAUTIFY.timeVisibility
        );
        return {
            bubbleMe: _normalizeChatBeautifyColor(source.bubbleMe, DEFAULT_CHAT_BEAUTIFY.bubbleMe),
            textMe: _normalizeChatBeautifyColor(source.textMe, DEFAULT_CHAT_BEAUTIFY.textMe),
            bubbleOther: _normalizeChatBeautifyColor(source.bubbleOther, DEFAULT_CHAT_BEAUTIFY.bubbleOther),
            textOther: _normalizeChatBeautifyColor(source.textOther, DEFAULT_CHAT_BEAUTIFY.textOther),
            bubbleStyle: ['wechat', 'rounded', 'capsule', 'square'].indexOf(source.bubbleStyle) >= 0 ? source.bubbleStyle : DEFAULT_CHAT_BEAUTIFY.bubbleStyle,
            avatarShape: ['circle', 'rounded', 'square'].indexOf(source.avatarShape) >= 0 ? source.avatarShape : DEFAULT_CHAT_BEAUTIFY.avatarShape,
            avatarVisibility: avatarVisibility,
            avatarFrame: _miniSafeText(source.avatarFrame, ''),
            avatarFrameScale: _normalizeChatBeautifyFloat(source.avatarFrameScale, 0.5, 2, DEFAULT_CHAT_BEAUTIFY.avatarFrameScale),
            avatarFrameOffsetX: _normalizeChatBeautifyNumber(source.avatarFrameOffsetX, -24, 24, DEFAULT_CHAT_BEAUTIFY.avatarFrameOffsetX),
            avatarFrameOffsetY: _normalizeChatBeautifyNumber(source.avatarFrameOffsetY, -24, 24, DEFAULT_CHAT_BEAUTIFY.avatarFrameOffsetY),
            timeVisibility: timeVisibility,
            readVisibility: 'none',
            bubbleCss: _normalizeChatBeautifyCssText(source.bubbleCss),
            globalCss: _normalizeChatBeautifyCssText(source.globalCss)
        };
    }

    function _formatChatBeautifyOffsetLabel(value) {
        return _normalizeChatBeautifyNumber(value, -24, 24, 0) + 'px';
    }

    function _formatChatBeautifyFrameScaleLabel(value) {
        return Math.round(_normalizeChatBeautifyFloat(value, 0.5, 2, DEFAULT_CHAT_BEAUTIFY.avatarFrameScale) * 100) + '%';
    }

    async function _loadGlobalChatBeautifyConfig(force) {
        if (chatBeautifyGlobalLoaded && !force) {
            return _normalizeChatBeautifyConfig(cachedGlobalChatBeautifyConfig);
        }
        let saved = {};
        try {
            saved = await localforage.getItem(CHAT_BEAUTIFY_STORAGE_KEY);
        } catch (e) {
            saved = {};
        }
        cachedGlobalChatBeautifyConfig = _normalizeChatBeautifyConfig(saved);
        chatBeautifyGlobalLoaded = true;
        return _normalizeChatBeautifyConfig(cachedGlobalChatBeautifyConfig);
    }

    async function _loadRoleChatBeautifyConfig(contactId, force) {
        const normalizedId = contactId === undefined || contactId === null ? '' : String(contactId).trim();
        if (!normalizedId) return null;
        if (Object.prototype.hasOwnProperty.call(cachedRoleChatBeautifyConfigs, normalizedId) && !force) {
            return cachedRoleChatBeautifyConfigs[normalizedId];
        }
        let saved = null;
        try {
            saved = await localforage.getItem(_getChatBeautifyRoleStorageKey(normalizedId));
        } catch (e) {
            saved = null;
        }
        cachedRoleChatBeautifyConfigs[normalizedId] = saved && typeof saved === 'object'
            ? Object.assign({}, saved)
            : null;
        return cachedRoleChatBeautifyConfigs[normalizedId];
    }

    async function _resolveChatBeautifyConfig(scope, force) {
        const normalizedScope = _normalizeChatBeautifyScope(scope);
        const globalConfig = await _loadGlobalChatBeautifyConfig(force);
        if (!_isRoleChatBeautifyScope(normalizedScope)) {
            return _normalizeChatBeautifyConfig(globalConfig);
        }
        const roleConfig = await _loadRoleChatBeautifyConfig(normalizedScope.contactId, force);
        if (!roleConfig) {
            return _normalizeChatBeautifyConfig(globalConfig);
        }
        return _normalizeChatBeautifyConfig(Object.assign({}, globalConfig, roleConfig));
    }

    async function _getScopedChatBeautifyContact(scope) {
        const normalizedScope = _normalizeChatBeautifyScope(scope);
        if (!_isRoleChatBeautifyScope(normalizedScope)) {
            return activeChatContact || null;
        }
        if (activeChatContact && String(activeChatContact.id) === normalizedScope.contactId) {
            return activeChatContact;
        }
        try {
            if (typeof contactDb !== 'undefined' && contactDb && contactDb.contacts && typeof contactDb.contacts.get === 'function') {
                return await contactDb.contacts.get(normalizedScope.contactId);
            }
        } catch (e) {}
        return null;
    }

    function _syncChatBeautifyControlState() {
        const config = currentChatBeautifyConfig;
        ['bubbleMe', 'textMe', 'bubbleOther', 'textOther'].forEach(function(key) {
            document.querySelectorAll('[data-chat-beautify-input="' + key + '"]').forEach(function(el) {
                if (el && el.value !== config[key]) el.value = config[key];
            });
        });

        document.querySelectorAll('[data-chat-beautify-choice]').forEach(function(el) {
            const key = el.getAttribute('data-chat-beautify-choice');
            const value = el.getAttribute('data-chat-beautify-value');
            el.classList.toggle('active', config[key] === value);
        });

        document.querySelectorAll('[data-chat-beautify-css-input]').forEach(function(el) {
            const key = el.getAttribute('data-chat-beautify-css-input');
            const nextValue = typeof config[key] === 'string' ? config[key] : '';
            if (el && el.value !== nextValue) el.value = nextValue;
        });

        ['avatarFrameScale', 'avatarFrameOffsetX', 'avatarFrameOffsetY'].forEach(function(key) {
            document.querySelectorAll('[data-chat-beautify-range="' + key + '"]').forEach(function(el) {
                const nextValue = String(config[key]);
                if (el && el.value !== nextValue) el.value = nextValue;
            });
            document.querySelectorAll('[data-chat-beautify-display="' + key + '"]').forEach(function(el) {
                if (!el) return;
                el.textContent = key === 'avatarFrameScale'
                    ? _formatChatBeautifyFrameScaleLabel(config[key])
                    : _formatChatBeautifyOffsetLabel(config[key]);
            });
        });
    }

    function _escapeChatBeautifyCssUrl(value) {
        return String(value || '')
            .replace(/\\/g, '\\\\')
            .replace(/"/g, '\\"')
            .replace(/\r\n?/g, '');
    }

    function _normalizeChatBeautifyAvatarFrameImage(base64Str, maxWidth) {
        return new Promise(function(resolve) {
            if (!base64Str || !/^data:image\//i.test(base64Str)) {
                resolve(base64Str || '');
                return;
            }
            const img = new Image();
            img.onload = function() {
                let width = Number(img.width) || 0;
                let height = Number(img.height) || 0;
                if (!width || !height) {
                    resolve(base64Str);
                    return;
                }
                const targetMaxWidth = Number(maxWidth) || 640;
                if (targetMaxWidth > 0 && width > targetMaxWidth) {
                    height = Math.max(1, Math.round((height * targetMaxWidth) / width));
                    width = targetMaxWidth;
                }
                const canvas = document.createElement('canvas');
                canvas.width = Math.max(1, Math.round(width));
                canvas.height = Math.max(1, Math.round(height));
                const ctx = canvas.getContext('2d', { alpha: true });
                if (!ctx) {
                    resolve(base64Str);
                    return;
                }
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                resolve(canvas.toDataURL('image/png'));
            };
            img.onerror = function() {
                resolve(base64Str);
            };
            img.src = base64Str;
        });
    }

    function _setChatBeautifyCustomStyle(styleId, cssText) {
        let styleEl = document.getElementById(styleId);
        if (!styleEl) {
            styleEl = document.createElement('style');
            styleEl.id = styleId;
            document.head.appendChild(styleEl);
        }
        styleEl.textContent = cssText || '';
    }

    function _scopeChatBeautifyCss(css, roots) {
        const raw = _normalizeChatBeautifyCssText(css);
        const targetRoots = Array.isArray(roots) ? roots.filter(Boolean) : [];
        if (!raw || !targetRoots.length) return '';
        const cleaned = raw.replace(/\/\*[\s\S]*?\*\//g, '').trim();
        if (!cleaned) return '';
        return cleaned.replace(/(^|{|})\s*([^@}{][^{}]*)\{/g, function(match, prefix, selectorText) {
            const scopedSelector = String(selectorText || '').split(',').map(function(item) {
                const selector = String(item || '').trim();
                if (!selector) return '';
                if (targetRoots.some(function(root) { return selector.indexOf(root) !== -1; })) {
                    return selector;
                }
                if (selector === ':root' || selector === 'html' || selector === 'body') {
                    return targetRoots.join(', ');
                }
                if (selector === '*') {
                    return targetRoots.map(function(root) { return root + ' *'; }).join(', ');
                }
                if (/^(html|body|:root)\b/.test(selector)) {
                    return targetRoots.map(function(root) { return selector + ' ' + root; }).join(', ');
                }
                return targetRoots.map(function(root) { return root + ' ' + selector; }).join(', ');
            }).filter(function(item) {
                return !!item;
            }).join(', ');
            if (!scopedSelector) return match;
            return prefix + '\n' + scopedSelector + ' {';
        });
    }

    function _applyChatBeautifyCustomCss(config) {
        const normalized = config && typeof config === 'object' ? config : currentChatBeautifyConfig;
        _setChatBeautifyCustomStyle(
            CHAT_BEAUTIFY_CUSTOM_STYLE_IDS.bubble,
            _scopeChatBeautifyCss(normalized.bubbleCss, CHAT_BEAUTIFY_BUBBLE_ROOTS)
        );
        _setChatBeautifyCustomStyle(
            CHAT_BEAUTIFY_CUSTOM_STYLE_IDS.global,
            _scopeChatBeautifyCss(normalized.globalCss, CHAT_BEAUTIFY_GLOBAL_ROOTS)
        );
    }

    function _applyChatBeautifyConfig(config) {
        const root = document.documentElement;
        currentChatBeautifyConfig = _normalizeChatBeautifyConfig(config);
        root.style.setProperty('--mini-chat-bubble-me', currentChatBeautifyConfig.bubbleMe);
        root.style.setProperty('--mini-chat-text-me', currentChatBeautifyConfig.textMe);
        root.style.setProperty('--mini-chat-bubble-other', currentChatBeautifyConfig.bubbleOther);
        root.style.setProperty('--mini-chat-text-other', currentChatBeautifyConfig.textOther);
        root.style.setProperty(
            '--mini-chat-avatar-frame-image',
            currentChatBeautifyConfig.avatarFrame
                ? 'url("' + _escapeChatBeautifyCssUrl(currentChatBeautifyConfig.avatarFrame) + '")'
                : 'none'
        );
        root.style.setProperty('--mini-chat-avatar-frame-scale', currentChatBeautifyConfig.avatarFrameScale);
        root.style.setProperty('--mini-chat-avatar-frame-offset-x', currentChatBeautifyConfig.avatarFrameOffsetX + 'px');
        root.style.setProperty('--mini-chat-avatar-frame-offset-y', currentChatBeautifyConfig.avatarFrameOffsetY + 'px');
        root.setAttribute('data-chat-bubble-style', currentChatBeautifyConfig.bubbleStyle);
        root.setAttribute('data-chat-avatar-shape', currentChatBeautifyConfig.avatarShape);
        root.setAttribute('data-chat-avatar-visibility', currentChatBeautifyConfig.avatarVisibility);
        root.setAttribute('data-chat-time-visibility', currentChatBeautifyConfig.timeVisibility);
        root.setAttribute('data-chat-read-visibility', 'none');
        root.removeAttribute('data-chat-hide-avatar');
        root.removeAttribute('data-chat-show-time');
        root.removeAttribute('data-chat-show-read');
        if (currentChatBeautifyConfig.avatarShape === 'circle') {
            root.style.setProperty('--mini-chat-avatar-radius', '50%');
        } else if (currentChatBeautifyConfig.avatarShape === 'rounded') {
            root.style.setProperty('--mini-chat-avatar-radius', '14px');
        } else {
            root.style.setProperty('--mini-chat-avatar-radius', '8px');
        }
        _applyChatBeautifyCustomCss(currentChatBeautifyConfig);
        _syncChatBeautifyControlState();
    }

    async function _loadChatBeautifyConfig(scope, force) {
        const normalizedScope = _normalizeChatBeautifyScope(scope || currentChatBeautifyScope);
        const scopeKey = _getChatBeautifyScopeKey(normalizedScope);
        if (chatBeautifyLoaded && !force && chatBeautifyLoadedScopeKey === scopeKey) {
            return currentChatBeautifyConfig;
        }
        const resolved = await _resolveChatBeautifyConfig(normalizedScope, force);
        currentChatBeautifyScope = normalizedScope;
        chatBeautifyLoaded = true;
        chatBeautifyLoadedScopeKey = scopeKey;
        _applyChatBeautifyConfig(resolved);
        return currentChatBeautifyConfig;
    }

    function _queueChatBeautifySave() {
        if (chatBeautifySaveTimer) clearTimeout(chatBeautifySaveTimer);
        const scopeSnapshot = _normalizeChatBeautifyScope(currentChatBeautifyScope);
        const configSnapshot = _normalizeChatBeautifyConfig(currentChatBeautifyConfig);
        chatBeautifySaveTimer = setTimeout(function() {
            if (_isRoleChatBeautifyScope(scopeSnapshot)) {
                cachedRoleChatBeautifyConfigs[scopeSnapshot.contactId] = Object.assign({}, configSnapshot);
                localforage.setItem(_getChatBeautifyRoleStorageKey(scopeSnapshot.contactId), configSnapshot).catch(function(err) {
                    console.error('[chat-beautify] 角色专属保存失败', err);
                });
                return;
            }
            cachedGlobalChatBeautifyConfig = _normalizeChatBeautifyConfig(configSnapshot);
            chatBeautifyGlobalLoaded = true;
            localforage.setItem(CHAT_BEAUTIFY_STORAGE_KEY, configSnapshot).catch(function(err) {
                console.error('[chat-beautify] 保存失败', err);
            });
        }, 120);
    }

    window.updateChatBeautifySetting = function(key, value) {
        const next = Object.assign({}, currentChatBeautifyConfig, {});
        next[key] = value;
        _applyChatBeautifyConfig(next);
        _queueChatBeautifySave();
        syncWechatBeautifyPreviews().catch(function(err) {
            console.error('[chat-beautify] 刷新预览失败', err);
        });
    };

    window.resetChatBeautifySettings = function() {
        _applyChatBeautifyConfig(DEFAULT_CHAT_BEAUTIFY);
        const scope = _normalizeChatBeautifyScope(currentChatBeautifyScope);
        if (_isRoleChatBeautifyScope(scope)) {
            cachedRoleChatBeautifyConfigs[scope.contactId] = _normalizeChatBeautifyConfig(DEFAULT_CHAT_BEAUTIFY);
            localforage.setItem(_getChatBeautifyRoleStorageKey(scope.contactId), currentChatBeautifyConfig).catch(function(err) {
                console.error('[chat-beautify] 角色专属重置失败', err);
            });
        } else {
            cachedGlobalChatBeautifyConfig = _normalizeChatBeautifyConfig(currentChatBeautifyConfig);
            chatBeautifyGlobalLoaded = true;
            localforage.setItem(CHAT_BEAUTIFY_STORAGE_KEY, currentChatBeautifyConfig).catch(function(err) {
                console.error('[chat-beautify] 重置失败', err);
            });
        }
        syncWechatBeautifyPreviews().catch(function(err) {
            console.error('[chat-beautify] 重置后刷新预览失败', err);
        });
    };

    window.triggerChatBeautifyAvatarFramePicker = function() {
        const input = document.getElementById('chat-beautify-avatar-frame-input');
        if (input) input.click();
    };

    window.handleChatBeautifyAvatarFrameChange = function(event) {
        const input = event && event.target;
        const file = input && input.files && input.files[0];
        if (!file) return;
        const rawType = String(file.type || '').toLowerCase();
        const rawName = String(file.name || '').toLowerCase();
        const isTransparentFriendlyImage = !rawType || /^image\/(png|webp|gif)$/.test(rawType) || /\.png$/.test(rawName);
        if (!isTransparentFriendlyImage) {
            input.value = '';
            if (typeof window.showMiniToast === 'function') {
                window.showMiniToast('头像框请上传透明 PNG');
            }
            return;
        }
        const reader = new FileReader();
        reader.onload = async function(e) {
            let result = e && e.target ? e.target.result : '';
            if (!result) return;
            result = await _normalizeChatBeautifyAvatarFrameImage(result, 640);
            const next = Object.assign({}, currentChatBeautifyConfig, {
                avatarFrame: result
            });
            _applyChatBeautifyConfig(next);
            _queueChatBeautifySave();
            syncWechatBeautifyPreviews().catch(function(err) {
                console.error('[chat-beautify] 头像框刷新失败', err);
            });
            if (typeof window.showMiniToast === 'function') {
                window.showMiniToast('头像框已添加并保存为 PNG');
            }
        };
        reader.readAsDataURL(file);
        input.value = '';
    };

    window.clearChatBeautifyAvatarFrame = function() {
        const next = Object.assign({}, currentChatBeautifyConfig, {
            avatarFrame: '',
            avatarFrameScale: DEFAULT_CHAT_BEAUTIFY.avatarFrameScale,
            avatarFrameOffsetX: 0,
            avatarFrameOffsetY: 0
        });
        _applyChatBeautifyConfig(next);
        _queueChatBeautifySave();
        syncWechatBeautifyPreviews().catch(function(err) {
            console.error('[chat-beautify] 清除头像框刷新失败', err);
        });
        if (typeof window.showMiniToast === 'function') {
            window.showMiniToast('头像框已移除');
        }
    };

    function _readChatBeautifyCssDraftValue(key) {
        const focused = document.activeElement;
        if (focused && focused.matches && focused.matches('[data-chat-beautify-css-input="' + key + '"]')) {
            return focused.value;
        }
        const input = document.querySelector('[data-chat-beautify-css-input="' + key + '"]');
        return input ? input.value : (currentChatBeautifyConfig[key] || '');
    }

    window.updateChatBeautifyCssDraft = function(key, value) {
        const normalizedValue = String(value === undefined || value === null ? '' : value).replace(/\r\n?/g, '\n');
        document.querySelectorAll('[data-chat-beautify-css-input="' + key + '"]').forEach(function(el) {
            if (el !== document.activeElement && el.value !== normalizedValue) {
                el.value = normalizedValue;
            }
        });
    };

    window.applyChatBeautifyCssDraft = function() {
        const next = Object.assign({}, currentChatBeautifyConfig, {
            bubbleCss: _readChatBeautifyCssDraftValue('bubbleCss'),
            globalCss: _readChatBeautifyCssDraftValue('globalCss')
        });
        _applyChatBeautifyConfig(next);
        _queueChatBeautifySave();
        syncWechatBeautifyPreviews().catch(function(err) {
            console.error('[chat-beautify] 自定义 CSS 应用失败', err);
        });
        if (typeof window.showMiniToast === 'function') {
            window.showMiniToast('聊天 CSS 已应用');
        }
    };

    window.resetChatBeautifyCssDraft = function() {
        const next = Object.assign({}, currentChatBeautifyConfig, {
            bubbleCss: '',
            globalCss: ''
        });
        _applyChatBeautifyConfig(next);
        _queueChatBeautifySave();
        syncWechatBeautifyPreviews().catch(function(err) {
            console.error('[chat-beautify] 自定义 CSS 恢复初始化失败', err);
        });
        if (typeof window.showMiniToast === 'function') {
            window.showMiniToast('已恢复初始化');
        }
    };

    window.copyChatBeautifyCssTemplate = async function(kind) {
        const key = kind === 'global' ? 'globalCss' : 'bubbleCss';
        const template = key === 'globalCss' ? CHAT_GLOBAL_CSS_TEMPLATE : CHAT_BUBBLE_CSS_TEMPLATE;
        document.querySelectorAll('[data-chat-beautify-css-input="' + key + '"]').forEach(function(el) {
            if (el.value !== template) el.value = template;
        });
        let copied = false;
        try {
            if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
                await navigator.clipboard.writeText(template);
                copied = true;
            }
        } catch (e) {}
        if (typeof window.showMiniToast === 'function') {
            window.showMiniToast(copied ? '模板已复制并填入' : '模板已填入');
        }
    };

    function _setBeautifyPreviewText(root, part, value) {
        if (!root) return;
        const el = root.querySelector('[data-preview-part="' + part + '"]');
        if (el) el.textContent = _miniSafeText(value, '');
    }

    function _setBeautifyPreviewImage(root, part, src) {
        if (!root) return;
        const img = root.querySelector('[data-preview-part="' + part + '"]');
        if (!img) return;
        applySafeImageSource(img, src);
    }

    function _applyBeautifyPreviewBackground(root, wallpaperSrc, fallbackSrc) {
        if (!root) return;
        const primary = _isUsableBeautifyImage(wallpaperSrc) ? wallpaperSrc : '';
        const secondary = primary ? '' : (_isUsableBeautifyImage(fallbackSrc) ? fallbackSrc : '');
        if (primary || secondary) {
            const bgSrc = (primary || secondary).replace(/"/g, '%22');
            const overlay = primary
                ? 'linear-gradient(180deg, rgba(9,17,29,0.18) 0%, rgba(9,17,29,0.28) 100%)'
                : 'linear-gradient(180deg, rgba(9,17,29,0.24) 0%, rgba(9,17,29,0.36) 100%)';
            root.style.background = overlay + ', url("' + bgSrc + '") center/cover no-repeat';
            return;
        }
        root.style.background = '';
    }

    async function _getUnifiedBeautifyWallpaper() {
        try {
            if (document.documentElement.getAttribute('data-theme') === 'custom') {
                const customTheme = await localforage.getItem('miffy_custom_theme');
                if (customTheme && _isUsableBeautifyImage(customTheme.wallpaper)) {
                    return customTheme.wallpaper;
                }
            }
        } catch (e) {}
        try {
            if (typeof imgDb !== 'undefined' && imgDb.images && typeof imgDb.images.get === 'function') {
                const record = await imgDb.images.get('wallpaper-preview');
                if (record && _isUsableBeautifyImage(record.src)) return record.src;
            }
        } catch (e) {}
        const previewImg = document.querySelector('#wallpaper-preview img');
        if (previewImg) {
            const previewSrc = previewImg.getAttribute('src') || previewImg.src || '';
            if (_isUsableBeautifyImage(previewSrc)) return previewSrc;
        }
        return '';
    }

    function _fillBeautifyPreview(root, data) {
        if (!root || !data) return;
        _setBeautifyPreviewText(root, 'scene', data.scene);
        _setBeautifyPreviewText(root, 'clock', data.clock);
        _setBeautifyPreviewText(root, 'peerText', data.peerText);
        _setBeautifyPreviewText(root, 'peerTime', data.peerTime);
        _setBeautifyPreviewText(root, 'meText', data.meText);
        _setBeautifyPreviewText(root, 'meTime', data.meTime);
        _setBeautifyPreviewImage(root, 'peerAvatar', data.peerAvatar);
        _setBeautifyPreviewImage(root, 'meAvatar', data.meAvatar);
        _applyBeautifyPreviewBackground(root, data.wallpaper, data.fallbackWallpaper);
    }

    function _buildBeautifyPreviewPayload(now, wallpaper, previewContact) {
        const sourceContact = previewContact || activeChatContact;
        const peerAvatar = sourceContact && sourceContact.roleAvatar
            ? sourceContact.roleAvatar
            : DEFAULT_AVATAR_DATA_URI;
        return {
            scene: '实时预览',
            clock: _formatBeautifyPreviewClock(now),
            peerAvatar: peerAvatar,
            meAvatar: _getWechatProfileAvatarSrc(),
            peerText: '这里会实时预览对方消息效果',
            peerTime: _formatBeautifyPreviewClock(now - 2 * 60000),
            meText: '颜色、样式、头像和时间会马上同步',
            meTime: _formatBeautifyPreviewClock(now),
            wallpaper: wallpaper,
            fallbackWallpaper: peerAvatar
        };
    }

    async function _getRoleBeautifyDisplayName(scope) {
        const contact = await _getScopedChatBeautifyContact(scope);
        if (!contact) return '角色';
        return getMiniContactDisplayName(contact, contact.roleName || '角色');
    }

    async function syncWechatBeautifyPages() {
        await _loadChatBeautifyConfig(currentChatBeautifyScope);
        const currentScope = _normalizeChatBeautifyScope(currentChatBeautifyScope);
        const globalNoteEl = document.getElementById('wechat-chat-beautify-page-note');
        if (globalNoteEl) {
            globalNoteEl.textContent = '下方预览直接对齐真实聊天结构，颜色、气泡、头像、时间戳和自定义 CSS 会实时同步到聊天界面；角色专属样式不会被这里串改。';
        }
        const now = Date.now();
        const wallpaper = await _getUnifiedBeautifyWallpaper();
        const currentContact = await _getScopedChatBeautifyContact(currentScope);
        const sharedPayload = _buildBeautifyPreviewPayload(now, wallpaper, currentContact || activeChatContact);

        const pageRoot = document.getElementById('wechat-chat-beautify-page-preview');
        if (pageRoot) {
            _fillBeautifyPreview(pageRoot, sharedPayload);
        }

        const roleTitleEl = document.getElementById('role-chat-beautify-page-title');
        const roleNoteEl = document.getElementById('role-chat-beautify-page-note');
        const rolePageRoot = document.getElementById('role-chat-beautify-page-preview');
        if (roleTitleEl || roleNoteEl || rolePageRoot) {
            const roleScope = _isRoleChatBeautifyScope(currentScope)
                ? currentScope
                : _normalizeChatBeautifyScope({
                    kind: 'role',
                    contactId: activeChatContact && activeChatContact.id
                });
            const roleContact = await _getScopedChatBeautifyContact(roleScope);
            const roleName = await _getRoleBeautifyDisplayName(roleScope);
            const shortRoleName = _miniShortText(roleName, 6) || 'TA';
            if (roleTitleEl) roleTitleEl.textContent = roleName + ' 的聊天美化';
            if (roleNoteEl) {
                roleNoteEl.textContent = '这里单独绑定你和' + roleName + '的真实聊天样式，只作用于这个角色，不会串到别的角色。';
            }
            if (rolePageRoot) {
                _fillBeautifyPreview(rolePageRoot, Object.assign({}, _buildBeautifyPreviewPayload(now, wallpaper, roleContact || activeChatContact), {
                    scene: shortRoleName + ' 聊天',
                    peerText: shortRoleName + ' 的消息会在这里实时预览',
                    meText: '你的气泡、头像和时间显示会同步变化'
                }));
            }
        }
    }
    window.syncWechatBeautifyPages = syncWechatBeautifyPages;

    async function syncWechatBeautifyPreviews() {
        await _loadChatBeautifyConfig(currentChatBeautifyScope);
        const now = Date.now();
        const wallpaper = await _getUnifiedBeautifyWallpaper();
        const currentContact = await _getScopedChatBeautifyContact(currentChatBeautifyScope);
        const sharedPayload = _buildBeautifyPreviewPayload(now, wallpaper, currentContact || activeChatContact);
        _fillBeautifyPreview(document.getElementById('theme-chat-beautify-preview'), Object.assign({}, sharedPayload, {
            scene: '聊天美化'
        }));
        _fillBeautifyPreview(document.getElementById('wechat-me-beautify-preview'), Object.assign({}, sharedPayload, {
            scene: '全局聊天'
        }));
        await syncWechatBeautifyPages();
    }
    window.syncWechatBeautifyPreviews = syncWechatBeautifyPreviews;

    function _bindWechatBeautifyPreviewObservers() {
        if (document.body && document.body._wechatBeautifyPreviewBound) return;
        if (document.body) document.body._wechatBeautifyPreviewBound = true;
        const observer = new MutationObserver(function() {
            syncWechatBeautifyPreviews().catch(function(err) {
                console.error('[beautify-preview] 自动刷新失败', err);
            });
        });
        [
            document.getElementById('text-wechat-me-name'),
            document.getElementById('text-wechat-sig'),
            document.querySelector('#wechat-avatar-big img'),
            document.querySelector('#wechat-avatar-sq img'),
            document.querySelector('#wallpaper-preview img')
        ].forEach(function(node) {
            if (!node) return;
            observer.observe(node, { childList: true, subtree: true, characterData: true, attributes: true });
        });
        observer.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme', 'data-button-style'] });
    }

    function _initWechatBeautifyPreviews() {
        _loadChatBeautifyConfig({ kind: 'global', contactId: '' }, false).catch(function(err) {
            console.error('[chat-beautify] 初始化失败', err);
        });
        _bindWechatBeautifyPreviewObservers();
        syncWechatBeautifyPreviews().catch(function(err) {
            console.error('[beautify-preview] 初始化失败', err);
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', _initWechatBeautifyPreviews);
    } else {
        _initWechatBeautifyPreviews();
    }

    async function openWechatChatBeautifyApp(returnView) {
        await _loadChatBeautifyConfig({ kind: 'global', contactId: '' }, true);
        await syncWechatBeautifyPreviews();
        const app = document.getElementById('wechat-chat-beautify-app');
        if (app) app.dataset.returnView = returnView === 'role-profile' ? 'role-profile' : 'wechat';
        if (typeof window.syncWechatOverlayStack === 'function') {
            if (returnView === 'role-profile') {
                window.syncWechatOverlayStack(['wechat-app', 'role-profile-app', 'wechat-chat-beautify-app']);
            } else {
                window.syncWechatOverlayStack(['wechat-app', 'wechat-chat-beautify-app']);
            }
        } else if (app) {
            app.style.display = 'flex';
        }
        const body = app ? app.querySelector('.app-body') : null;
        if (body) body.scrollTop = 0;
    }
    window.openWechatChatBeautifyApp = openWechatChatBeautifyApp;

    function closeWechatChatBeautifyApp() {
        const app = document.getElementById('wechat-chat-beautify-app');
        const returnView = app ? app.dataset.returnView : '';
        if (app) app.dataset.returnView = '';
        if (returnView === 'role-profile' && activeChatContact && activeChatContact.id) {
            _loadChatBeautifyConfig({ kind: 'role', contactId: activeChatContact.id }, true).catch(function(err) {
                console.error('[chat-beautify] 返回角色页恢复专属样式失败', err);
            });
        } else {
            _loadChatBeautifyConfig({ kind: 'global', contactId: '' }, true).catch(function(err) {
                console.error('[chat-beautify] 返回通用样式失败', err);
            });
        }
        if (typeof window.syncWechatOverlayStack === 'function') {
            if (returnView === 'role-profile') {
                window.syncWechatOverlayStack(['wechat-app', 'role-profile-app']);
            } else {
                window.syncWechatOverlayStack(['wechat-app']);
            }
            return;
        }
        if (app) app.style.display = 'none';
    }
    window.closeWechatChatBeautifyApp = closeWechatChatBeautifyApp;

    async function openRoleChatBeautifyApp() {
        if (!activeChatContact || !activeChatContact.id) return;
        await _loadChatBeautifyConfig({ kind: 'role', contactId: activeChatContact.id }, true);
        await syncWechatBeautifyPreviews();
        const app = document.getElementById('role-chat-beautify-app');
        if (typeof window.syncWechatOverlayStack === 'function') {
            window.syncWechatOverlayStack(['wechat-app', 'role-profile-app', 'role-chat-beautify-app']);
        } else if (app) {
            app.style.display = 'flex';
        }
        const body = app ? app.querySelector('.app-body') : null;
        if (body) body.scrollTop = 0;
    }
    window.openRoleChatBeautifyApp = openRoleChatBeautifyApp;

    function closeRoleChatBeautifyApp() {
        if (activeChatContact && activeChatContact.id) {
            _loadChatBeautifyConfig({ kind: 'role', contactId: activeChatContact.id }, true).catch(function(err) {
                console.error('[chat-beautify] 关闭专属页恢复样式失败', err);
            });
        }
        if (typeof window.syncWechatOverlayStack === 'function') {
            window.syncWechatOverlayStack(['wechat-app', 'role-profile-app']);
            return;
        }
        const app = document.getElementById('role-chat-beautify-app');
        if (app) app.style.display = 'none';
    }
    window.closeRoleChatBeautifyApp = closeRoleChatBeautifyApp;
    window.restoreWechatGlobalChatBeautify = function() {
        _loadChatBeautifyConfig({ kind: 'global', contactId: '' }, true).catch(function(err) {
            console.error('[chat-beautify] 恢复通用样式失败', err);
        });
    };

    function _miniSafeMoney(value, fallback) {
        const raw = String(value === undefined || value === null ? '' : value).replace(/[^\d.]/g, '');
        const num = parseFloat(raw);
        if (!isNaN(num) && num >= 0) return num.toFixed(2);
        return fallback || '0.00';
    }

    function _miniSafePositiveInt(value, fallback) {
        const num = parseInt(value, 10);
        if (!isNaN(num) && num > 0) return num;
        return fallback || 1;
    }

    function _miniEscapeAttr(value) {
        return String(value || '')
            .replace(/&/g, '&amp;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }

    // 通用文本转义（供聊天详情/卡片详情等作用域外逻辑复用）
    function _safeTextHtml(raw) {
        const normalized = String(raw || '')
            .replace(/\r\n?/g, '\n')
            .replace(/[ \t]+\n/g, '\n')
            .replace(/\n{3,}/g, '\n\n')
            .replace(/([^\n])\n(?=[^\n])/g, '$1 ');
        return normalized
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/\n/g, '<br>');
    }

    function _miniNormalizeItems(items, fallbackName, fallbackDesc) {
        const arr = Array.isArray(items) ? items : [];
        const normalized = arr.map(function(item, index) {
            const base = item && typeof item === 'object' ? item : {};
            return {
                name: _miniSafeText(base.name, fallbackName || ('项目' + (index + 1))),
                desc: _miniSafeText(base.desc || base.spec, fallbackDesc || ''),
                qty: _miniSafePositiveInt(base.qty, 1),
                price: _miniSafeMoney(base.price, '')
            };
        }).filter(function(item) {
            return !!item.name;
        });
        if (normalized.length > 0) return normalized;
        return [{
            name: _miniSafeText(fallbackName, '项目'),
            desc: _miniSafeText(fallbackDesc, ''),
            qty: 1,
            price: ''
        }];
    }

    function _miniNormalizeForwardSender(sender) {
        const key = _miniSafeText(sender, '').toLowerCase();
        if (key === 'me' || key === 'user' || key === 'myprofile') return 'me';
        return 'role';
    }

    function _miniStripHtmlText(text) {
        return String(text || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
    }

    function _miniCompactText(text, maxLen) {
        const clean = _miniStripHtmlText(text);
        const limit = Number(maxLen) > 0 ? Number(maxLen) : 40;
        if (!clean) return '';
        return clean.length > limit ? (clean.slice(0, limit) + '…') : clean;
    }

    function _miniLegacyForwardMessageText(rawMsg) {
        const msg = rawMsg && typeof rawMsg === 'object' ? rawMsg : {};
        const type = _miniSafeText(msg.type, 'text');
        const content = msg.content;
        switch (type) {
            case 'text':
            case 'html':
                return _miniStripHtmlText(typeof content === 'string' ? content : '');
            case 'voice':
                return '[语音] ' + _miniSafeText(content && content.text ? content.text : '', '');
            case 'image':
            case 'uploaded_image':
                return '[图片]' + _miniSafeText(msg.isEmoticon ? msg.emoticonName : '', '');
            case 'picture_description':
                return '[图片] ' + _miniSafeText(content && content.description ? content.description : '', '');
            case 'red_packet':
                return '[红包] ' + _miniSafeText(content && content.blessing ? content.blessing : '', '');
            case 'transfer':
                return '[转账] ¥' + _miniSafeMoney(content && content.amount ? content.amount : '', '0.00');
            case 'music_share':
                return '[音乐] ' + _miniSafeText(content && content.title ? content.title : '', '');
            case 'location_share':
                return '[位置] ' + _miniSafeText(content && content.name ? content.name : '', '');
            case 'post_share':
                return '[分享的帖子]';
            case 'product_share': {
                const product = content && typeof content === 'object' ? (content.productDetails || {}) : {};
                return '[分享的商品] ' + _miniSafeText(product.name, '');
            }
            default:
                if (typeof content === 'string') return _miniStripHtmlText(content);
                if (content && typeof content === 'object') {
                    if (content.text) return _miniSafeText(content.text, '');
                    if (content.description) return _miniSafeText(content.description, '');
                }
                return '[' + type + ']';
        }
    }

    function _miniNormalizeLegacyForwardBundle(raw) {
        const legacy = raw && raw.content && typeof raw.content === 'object' ? raw.content : raw;
        if (!legacy || typeof legacy !== 'object') return null;
        const participants = legacy.participants && typeof legacy.participants === 'object' ? legacy.participants : {};
        const messages = (Array.isArray(legacy.messages) ? legacy.messages : []).map(function(item) {
            const base = item && typeof item === 'object' ? item : {};
            const senderKey = _miniSafeText(base.sender, '');
            const profile = participants[senderKey] && typeof participants[senderKey] === 'object'
                ? participants[senderKey]
                : null;
            const speaker = _miniSafeText(profile && profile.name ? profile.name : base.senderName, '');
            return {
                sender: _miniNormalizeForwardSender(senderKey),
                speaker: speaker,
                content: _miniSafeText(_miniLegacyForwardMessageText(base), '[消息]'),
                timeStr: _miniSafeText(base.timeStr || base.time, '')
            };
        }).filter(function(item) {
            return !!item.content;
        });

        let sourceUserName = _miniSafeText(raw.sourceUserName || legacy.sourceUserName, '');
        if (!sourceUserName) {
            const userCandidateKeys = ['myprofile', 'user', 'me'];
            for (let i = 0; i < userCandidateKeys.length; i++) {
                const profile = participants[userCandidateKeys[i]] && typeof participants[userCandidateKeys[i]] === 'object'
                    ? participants[userCandidateKeys[i]]
                    : null;
                sourceUserName = _miniSafeText(profile && profile.name ? profile.name : '', '');
                if (sourceUserName) break;
            }
        }

        let sourceContactName = _miniSafeText(legacy.sourceContactName || raw.sourceContactName, '');
        if (!sourceContactName) {
            const candidateKeys = Object.keys(participants).filter(function(key) {
                const normalizedKey = String(key || '').toLowerCase();
                return normalizedKey !== 'user'
                    && normalizedKey !== 'myprofile'
                    && normalizedKey !== 'me'
                    && normalizedKey !== 'system'
                    && normalizedKey !== 'system_separator';
            });
            if (candidateKeys.length === 1) {
                const candidate = participants[candidateKeys[0]];
                sourceContactName = _miniSafeText(candidate && candidate.name ? candidate.name : '', '');
            }
        }
        if (!sourceContactName) {
            sourceContactName = _miniSafeText(legacy.sourceChatName || raw.title, '角色');
        }

        const previewLines = messages.slice(0, 4).map(function(item) {
            const speaker = item.speaker || (item.sender === 'me' ? (sourceUserName || '我') : sourceContactName || '对方');
            return _miniCompactText(speaker + '：' + item.content, 40);
        }).filter(function(line) {
            return !!line;
        });

        return {
            schema: MINI_PROTOCOL_VERSION,
            type: 'forward_bundle',
            title: _miniSafeText(raw.title || legacy.sourceChatName || legacy.title, '聊天记录'),
            note: _miniSafeText(raw.note || legacy.note, ''),
            sourceUserName: _miniSafeText(raw.sourceUserName || sourceUserName, sourceUserName || ''),
            sourceContactId: _miniSafeText(raw.sourceContactId || legacy.sourceContactId, ''),
            sourceContactName: _miniSafeText(raw.sourceContactName || sourceContactName, sourceContactName || '角色'),
            favoriteRecordId: _miniSafeText(raw.favoriteRecordId || legacy.favoriteRecordId, ''),
            previewLines: previewLines,
            messages: messages
        };
    }

    function normalizeMiniStructuredPayload(raw) {
        if (!raw || typeof raw !== 'object' || !raw.type) return null;
        switch (raw.type) {
            case 'voice_message': {
                const transcript = _miniSafeText(raw.transcript || raw.content, '');
                return {
                    schema: MINI_PROTOCOL_VERSION,
                    type: 'voice_message',
                    transcript: transcript,
                    durationSec: Math.max(1, parseInt(raw.durationSec || raw.duration || Math.ceil(transcript.length / 3), 10) || 1)
                };
            }
            case 'red_packet': {
                return {
                    schema: MINI_PROTOCOL_VERSION,
                    type: 'red_packet',
                    amount: _miniSafeMoney(raw.amount, '0.00'),
                    memo: _miniSafeText(raw.memo || raw.greeting || raw.desc || raw.content, '恭喜发财，大吉大利'),
                    status: ['claimed', 'unclaimed'].includes(raw.status) ? raw.status : 'unclaimed'
                };
            }
            case 'transaction':
            case 'transfer': {
                return {
                    schema: MINI_PROTOCOL_VERSION,
                    type: 'transfer',
                    amount: _miniSafeMoney(raw.amount, '0.00'),
                    memo: _miniSafeText(raw.memo || raw.note || raw.desc || raw.content, '转账'),
                    status: ['pending', 'received', 'refunded'].includes(raw.status) ? raw.status : 'pending'
                };
            }
            case 'send_gift':
            case 'gift':
            case 'gift_delivery': {
                return {
                    schema: MINI_PROTOCOL_VERSION,
                    type: 'gift_delivery',
                    note: _miniSafeText(raw.note || raw.message || raw.desc || raw.content, '送你一份心意'),
                    status: ['sent', 'received'].includes(raw.status) ? raw.status : 'sent',
                    items: _miniNormalizeItems(raw.items, raw.item || '礼物', raw.desc || '')
                };
            }
            case 'takeaway':
            case 'takeout_delivery': {
                const firstItem = Array.isArray(raw.items) && raw.items[0] && typeof raw.items[0] === 'object'
                    ? raw.items[0]
                    : {};
                const items = _miniNormalizeItems(raw.items, raw.item || '外卖', raw.desc || '');
                const total = _miniSafeMoney(
                    raw.total,
                    items.reduce(function(sum, item) {
                        const price = parseFloat(item.price || '0');
                        return sum + (isNaN(price) ? 0 : (price * item.qty));
                    }, 0).toFixed(2)
                );
                return {
                    schema: MINI_PROTOCOL_VERSION,
                    type: 'takeout_delivery',
                    restaurant: _miniSafeText(raw.restaurant || firstItem.restaurant || firstItem.store, '暖心外卖'),
                    items: items,
                    deliveryFee: _miniSafeMoney(raw.deliveryFee || raw.delivery_fee, '0.00'),
                    total: total,
                    eta: _miniSafeText(raw.eta, '尽快送达'),
                    note: _miniSafeText(raw.note || raw.desc || raw.content, '给你点了外卖'),
                    receiver: _miniSafeText(raw.receiver, ''),
                    status: ['preparing', 'delivering', 'arrived'].includes(raw.status) ? raw.status : 'preparing'
                };
            }
            case 'call':
            case 'video_call':
            case 'call_invite': {
                const mode = raw.mode === 'video' || raw.type === 'video_call' ? 'video' : 'voice';
                const status = ['ringing', 'missed', 'ended', 'declined', 'connected'].includes(raw.status) ? raw.status : 'ringing';
                return {
                    schema: MINI_PROTOCOL_VERSION,
                    type: 'call_invite',
                    mode: mode,
                    status: status,
                    note: _miniSafeText(raw.note || raw.content, mode === 'video' ? '发起视频通话' : '发起语音通话')
                };
            }
            case 'forward':
            case 'forward_bundle': {
                const messages = (Array.isArray(raw.messages) ? raw.messages : []).map(function(item) {
                    const base = item && typeof item === 'object' ? item : {};
                    return {
                        sender: _miniNormalizeForwardSender(base.sender),
                        speaker: _miniSafeText(base.speaker || base.senderName, ''),
                        content: _miniSafeText(base.content, ''),
                        timeStr: _miniSafeText(base.timeStr, '')
                    };
                }).filter(function(item) {
                    return !!item.content;
                });
                const previewLines = (Array.isArray(raw.previewLines) ? raw.previewLines : []).map(function(line) {
                    return _miniSafeText(line, '');
                }).filter(function(line) {
                    return !!line;
                }).slice(0, 4);
                const fallbackPreviewLines = messages.slice(0, 4).map(function(item) {
                    const speaker = item.speaker || (item.sender === 'me'
                        ? (_miniSafeText(raw.sourceUserName, '') || '我')
                        : (_miniSafeText(raw.sourceContactName, '') || '对方'));
                    return _miniCompactText(speaker + '：' + item.content, 40);
                }).filter(function(line) {
                    return !!line;
                });
                return {
                    schema: MINI_PROTOCOL_VERSION,
                    type: 'forward_bundle',
                    title: _miniSafeText(raw.title, '聊天记录'),
                    note: _miniSafeText(raw.note, ''),
                    sourceUserName: _miniSafeText(raw.sourceUserName, ''),
                    sourceContactId: _miniSafeText(raw.sourceContactId, ''),
                    sourceContactName: _miniSafeText(raw.sourceContactName, '角色'),
                    favoriteRecordId: _miniSafeText(raw.favoriteRecordId, ''),
                    previewLines: previewLines.length ? previewLines : fallbackPreviewLines,
                    messages: messages
                };
            }
            case 'chat_history_share':
                return _miniNormalizeLegacyForwardBundle(raw);
            default:
                return null;
        }
    }

    function parseMiniStructuredPayload(content) {
        if (!content || typeof content !== 'string') return null;
        try {
            return normalizeMiniStructuredPayload(JSON.parse(content));
        } catch (e) {
            return null;
        }
    }

    function createMiniStructuredMessage(type, payload) {
        const normalized = normalizeMiniStructuredPayload(Object.assign({ type: type }, payload || {}));
        return normalized ? JSON.stringify(normalized) : '';
    }

    function isMiniStructuredPayloadType(type) {
        return MINI_STRUCTURED_TYPES.has(type);
    }

    function getMiniStructuredPreview(parsed) {
        if (!parsed || !parsed.type) return '';
        if (parsed.type === 'voice_message') return '[语音] ' + (parsed.transcript || '');
        if (parsed.type === 'red_packet') {
            const statusText = parsed.status === 'claimed' ? '已领取' : '待领取';
            return `[红包] ¥${parsed.amount} ${parsed.memo} (${statusText})`;
        }
        if (parsed.type === 'transfer') {
            const statusMap = { pending: '待收款', received: '已收款', refunded: '已退回' };
            return `[转账] ¥${parsed.amount} ${parsed.memo} (${statusMap[parsed.status] || '待收款'})`;
        }
        if (parsed.type === 'gift_delivery') {
            const names = parsed.items.slice(0, 2).map(function(item) { return item.name; }).join('、');
            return `[礼物] ${names || '礼物'}${parsed.note ? ' · ' + parsed.note : ''}`;
        }
        if (parsed.type === 'takeout_delivery') {
            const names = parsed.items.slice(0, 2).map(function(item) { return item.name; }).join('、');
            const head = parsed.restaurant ? (parsed.restaurant + ' · ') : '';
            return `[外卖] ${head}${names || '外卖'}${parsed.eta ? ' · ' + parsed.eta : ''}`;
        }
        if (parsed.type === 'call_invite') {
            const modeLabel = parsed.mode === 'video' ? '视频通话' : '语音通话';
            return '[' + modeLabel + '] ' + (parsed.note || '通话邀请');
        }
        if (parsed.type === 'forward_bundle') {
            return '[转发聊天记录] ' + (parsed.note || parsed.title || '聊天记录');
        }
        return '';
    }

    // 提取消息纯文本（用于引用、列表展示、过滤HTML和JSON等）
    function extractMsgPureText(content) {
        if (!content) return '';
        const structured = parseMiniStructuredPayload(content);
        if (structured) return getMiniStructuredPreview(structured);
        try {
            const parsed = JSON.parse(content);
            if (parsed.type === 'camera') return '[相片] ' + (parsed.content || '');
            if (parsed.type === 'image') return '[图片]';
            if (parsed.type === 'emoticon') return `[表情] ${parsed.desc || ''}`;
            if (parsed.type === 'location') return `[定位] ${parsed.address || ''}`;
            if (parsed.content) return parsed.content;
        } catch(e) {}
        if (content.startsWith('[CAMERA]')) return '[相片] ' + content.substring(8);
        // 过滤 HTML 标签获取纯文本 (解决掉代码问题)
        // 核心修复：把翻译气泡的分割线替换为空格，防止外文和中文粘连
        let safeContent = content.replace(/<div class="msg-translate-divider"><\/div>/g, ' ');
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = safeContent;
        return tempDiv.textContent || tempDiv.innerText || safeContent;
    }

    function normalizeWechatRecordDetailMessages(rawMessages, options) {
        const opt = options && typeof options === 'object' ? options : {};
        const meName = _miniSafeText(opt.meName, '我');
        const peerName = _miniSafeText(opt.peerName, '对方');
        return (Array.isArray(rawMessages) ? rawMessages : []).map(function(msg, index) {
            const isMe = !!(msg && msg.sender === 'me');
            const fallbackSpeaker = isMe ? meName : peerName;
            const speaker = _miniSafeText(msg && msg.speaker ? msg.speaker : '', fallbackSpeaker) || fallbackSpeaker;
            const contentText = extractMsgPureText(msg && msg.content ? msg.content : '') || '[消息]';
            return {
                index: index,
                isMe: isMe,
                speaker: speaker,
                contentText: contentText,
                timeStr: _miniSafeText(msg && msg.timeStr ? msg.timeStr : '', '')
            };
        }).filter(function(item) {
            return !!item.contentText;
        });
    }

    function buildWechatRecordDetailRowsHtml(normalizedMessages, options) {
        const opt = options && typeof options === 'object' ? options : {};
        const myAvatar = getSafeAvatarSrc(opt.myAvatar || '');
        const peerAvatar = getSafeAvatarSrc(opt.peerAvatar || '');
        return normalizedMessages.map(function(item) {
            const avatar = item.isMe ? myAvatar : peerAvatar;
            const rowClass = item.isMe ? 'msg-right' : 'msg-left';
            const alignClass = item.isMe ? 'msg-right' : 'msg-left';
            const timeText = item.timeStr || '时间未记录';
            return '' +
                '<div class="chat-msg-row ' + rowClass + ' wechat-record-detail-row">' +
                    '<div class="chat-msg-avatar"><img src="' + _miniEscapeAttr(avatar) + '" loading="lazy" decoding="async" onerror="this.onerror=null;this.src=\'' + _miniEscapeAttr(DEFAULT_AVATAR_DATA_URI) + '\';"></div>' +
                    '<div class="wechat-record-detail-bubble-wrap ' + alignClass + '">' +
                        '<div class="wechat-record-detail-speaker">' + _safeTextHtml(item.speaker) + '</div>' +
                        '<div class="msg-bubble-wrapper" style="margin-top:0; max-width:100%; flex:0 1 auto;">' +
                            '<div class="chat-msg-content">' + _safeTextHtml(item.contentText) + '</div>' +
                            '<div class="chat-timestamp">' + _safeTextHtml(timeText) + '</div>' +
                        '</div>' +
                    '</div>' +
                '</div>';
        }).join('');
    }

    function renderWechatRecordDetailPage(options) {
        const opt = options && typeof options === 'object' ? options : {};
        const titleEl = document.getElementById(opt.titleElementId || '');
        const bodyEl = document.getElementById(opt.bodyElementId || '');
        if (!bodyEl) return;

        const meName = _miniSafeText(opt.meName, '我');
        const peerName = _miniSafeText(opt.peerName, '对方');
        const heading = _miniSafeText(opt.heading, meName + '和' + peerName + '的聊天记录');
        const normalizedMessages = normalizeWechatRecordDetailMessages(opt.messages, {
            meName: meName,
            peerName: peerName
        });

        if (titleEl) titleEl.textContent = heading;
        if (!normalizedMessages.length) {
            bodyEl.innerHTML = '<div class="wechat-record-detail-empty">暂无消息</div>';
            return;
        }

        // 聊天关系与原时间线只作为内部判断依据保留在代码和 prompt 中，不直接展示到详情页。
        bodyEl.innerHTML = buildWechatRecordDetailRowsHtml(normalizedMessages, {
            myAvatar: opt.myAvatar || '',
            peerAvatar: opt.peerAvatar || ''
        });
    }

    function buildMiniForwardBundlePromptText(structured, options) {
        if (!structured || structured.type !== 'forward_bundle') return '';
        const opt = options && typeof options === 'object' ? options : {};
        const meName = _miniPickText(opt.meName, getMiniProfileNickname(structured.sourceUserName), '我');
        const currentRoleName = _miniSafeText(opt.currentRoleName, '角色');
        const currentRoleId = _miniSafeText(opt.currentRoleId, '');
        const sourceContactId = _miniSafeText(structured.sourceContactId, '');
        const sourceContactName = _miniSafeText(structured.sourceContactName, '对方');
        const cardLabel = _miniSafeText(structured.note || structured.title, '');
        const sameAsCurrentRole = !!(
            (currentRoleId && sourceContactId && currentRoleId === sourceContactId) ||
            (currentRoleName && sourceContactName && currentRoleName === sourceContactName)
        );
        const normalizedMessages = normalizeWechatRecordDetailMessages(structured.messages, {
            meName: meName,
            peerName: sourceContactName
        });
        const timelineText = normalizedMessages.length ? normalizedMessages.map(function(item, index) {
            const timePrefix = item.timeStr ? ('[' + item.timeStr + '] ') : '';
            return (index + 1) + '. ' + timePrefix + item.speaker + '：' + item.contentText;
        }).join('\n') : '暂无可读消息';
        const relationLine = sameAsCurrentRole
            ? '这张卡片记录的是你和用户此前的聊天片段，可以视为你们已经发生过的事实。'
            : '这张卡片记录的是用户与「' + sourceContactName + '」之间的聊天，不是你「' + currentRoleName + '」本人说过的话，绝对不要错认身份。';
        const taskLine = sameAsCurrentRole
            ? '这是用户刚在当前线上聊天输入栏里翻出来发给你的旧聊天记录。你要先看清时间线，再以此刻正在聊天的你继续回应。'
            : '这是用户刚在当前线上聊天输入栏里转发给你看的聊天记录。你要先看懂双方关系和时间线，再以当前正在聊天的你表达态度、情绪、判断或追问。';
        return [
            '【转发聊天记录卡片】',
            cardLabel ? ('- 卡片标题：' + cardLabel) : '',
            '- 当前与你聊天的身份：' + currentRoleName,
            '- 卡片原聊天双方：' + meName + ' ↔ ' + sourceContactName,
            '- 关系判断：' + relationLine,
            '【卡片时间线】',
            timelineText,
            '【你的回复任务】',
            taskLine,
            '- 你只能以当前身份继续聊天，不能把卡片里另一位角色的话当成自己说过的。',
            '- 如果卡片内容与当前线上、线下、信息或世界书上下文冲突，以当前系统注入的身份与事实为准。'
        ].filter(function(line) {
            return !!line;
        }).join('\n');
    }

    function buildMiniForwardBundleRestoreText(structured, options) {
        if (!structured || structured.type !== 'forward_bundle') return '';
        const opt = options && typeof options === 'object' ? options : {};
        const meName = _miniPickText(opt.meName, getMiniProfileNickname(structured.sourceUserName), '我');
        const sourceContactName = _miniPickText(opt.peerName, structured.sourceContactName, '对方');
        const cardLabel = _miniSafeText(structured.note || structured.title, '');
        const normalizedMessages = normalizeWechatRecordDetailMessages(structured.messages, {
            meName: meName,
            peerName: sourceContactName
        });
        const lines = [];
        if (cardLabel) lines.push('转发聊天记录：' + cardLabel);
        lines.push(meName + '和' + sourceContactName + '的聊天记录');
        normalizedMessages.forEach(function(item) {
            const timePrefix = item.timeStr ? ('[' + item.timeStr + '] ') : '';
            lines.push(timePrefix + item.speaker + '：' + item.contentText);
        });
        return lines.join('\n').trim();
    }

    window.getMiniContactDisplayName = getMiniContactDisplayName;
    window.getMiniProfileNickname = getMiniProfileNickname;
    window.renderWechatRecordDetailPage = renderWechatRecordDetailPage;
    window.buildMiniForwardBundlePromptText = buildMiniForwardBundlePromptText;
    window.buildMiniForwardBundleRestoreText = buildMiniForwardBundleRestoreText;

    function extractTopLevelJsonObjects(rawText) {
        const text = String(rawText || '');
        const objects = [];
        let depth = 0;
        let start = -1;
        let inString = false;
        let escaped = false;
        for (let i = 0; i < text.length; i++) {
            const ch = text[i];
            if (inString) {
                if (escaped) {
                    escaped = false;
                } else if (ch === '\\') {
                    escaped = true;
                } else if (ch === '"') {
                    inString = false;
                }
                continue;
            }
            if (ch === '"') {
                inString = true;
                continue;
            }
            if (ch === '{') {
                if (depth === 0) start = i;
                depth++;
            } else if (ch === '}') {
                depth--;
                if (depth === 0 && start !== -1) {
                    objects.push(text.slice(start, i + 1));
                    start = -1;
                }
            }
        }
        return objects;
    }

    function repairMiniRoleReplyText(replyText) {
        let cleanText = String(replyText || '').trim();
        cleanText = cleanText.replace(/```(?:json)?/gi, '').replace(/```/g, '').trim();
        cleanText = cleanText.replace(/\]\s*\[/g, ',');
        if (cleanText.startsWith('[') && !cleanText.endsWith(']')) {
            const objectChunks = extractTopLevelJsonObjects(cleanText);
            if (objectChunks.length > 0) {
                return '[' + objectChunks.join(',') + ']';
            }
        }
        return cleanText;
    }

    function normalizeRoleReplyArray(replyText) {
        const raw = String(replyText || '').trim();
        if (!raw) return [];
        let cleanText = repairMiniRoleReplyText(raw);
        const firstBracket = cleanText.indexOf('[');
        const lastBracket = cleanText.lastIndexOf(']');
        if (firstBracket !== -1 && lastBracket !== -1 && lastBracket > firstBracket) {
            const arrayCandidate = cleanText.substring(firstBracket, lastBracket + 1);
            try {
                const parsedArray = JSON.parse(arrayCandidate);
                if (Array.isArray(parsedArray)) return parsedArray;
            } catch (e) {}
        }
        const firstBrace = cleanText.indexOf('{');
        const lastBrace = cleanText.lastIndexOf('}');
        if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
            const objectCandidate = cleanText.substring(firstBrace, lastBrace + 1);
            try {
                const parsedObject = JSON.parse(objectCandidate);
                if (Array.isArray(parsedObject)) return parsedObject;
                if (parsedObject && typeof parsedObject === 'object') return [parsedObject];
            } catch (e) {}
        }
        const objectChunks = extractTopLevelJsonObjects(cleanText);
        if (objectChunks.length > 0) {
            const parsedChunks = objectChunks.map(function(chunk) {
                try { return JSON.parse(chunk); } catch (e) { return null; }
            }).filter(function(item) {
                return !!item && typeof item === 'object';
            });
            if (parsedChunks.length > 0) return parsedChunks;
        }
        const lineResults = [];
        let hasStructuredObject = false;
        raw.split('\n').forEach(function(line) {
            const trimmed = line.trim();
            if (!trimmed) return;
            const normalizedLine = trimmed.replace(/^[,\[]+/, '').replace(/[,\]]+$/, '').trim();
            let parsedLine = null;
            if (normalizedLine) {
                try {
                    parsedLine = JSON.parse(normalizedLine);
                } catch (e) {
                    const braceStart = normalizedLine.indexOf('{');
                    const braceEnd = normalizedLine.lastIndexOf('}');
                    if (braceStart !== -1 && braceEnd > braceStart) {
                        const objCandidate = normalizedLine.slice(braceStart, braceEnd + 1);
                        try { parsedLine = JSON.parse(objCandidate); } catch (e2) {}
                    }
                }
            }
            if (Array.isArray(parsedLine)) {
                parsedLine.forEach(function(item) {
                    if (item && typeof item === 'object') {
                        lineResults.push(item);
                        hasStructuredObject = true;
                    }
                });
                return;
            }
            if (parsedLine && typeof parsedLine === 'object') {
                lineResults.push(parsedLine);
                hasStructuredObject = true;
                return;
            }
            lineResults.push({ type: 'text', content: trimmed });
        });
        if (hasStructuredObject) return lineResults;
        return lineResults.map(function(item) {
            if (item && typeof item === 'object' && item.type) return item;
            return { type: 'text', content: String(item && item.content ? item.content : '') };
        });
    }

    function autoGrowTextarea(el) {
        if (!el || el.tagName !== 'TEXTAREA') return;
        if (!el.dataset.autoGrowBound) {
            const cs = window.getComputedStyle(el);
            const curH = parseFloat(cs.height) || el.offsetHeight || 0;
            const minH = parseFloat(cs.minHeight);
            const maxH = parseFloat(cs.maxHeight);
            const lineH = parseFloat(cs.lineHeight);
            const padTop = parseFloat(cs.paddingTop) || 0;
            const padBottom = parseFloat(cs.paddingBottom) || 0;
            const rowCount = Math.max(1, parseInt(el.getAttribute('rows'), 10) || 1);
            const naturalMin = Math.ceil(((Number.isFinite(lineH) ? lineH : 20) * rowCount) + padTop + padBottom);
            const dynamicInputIds = new Set(['chat-input-main', 'sms-input-field', 'offline-input-field']);
            const useSoftMinHeight = dynamicInputIds.has(el.id);
            const finalMinH = useSoftMinHeight
                ? Math.max(Number.isFinite(minH) ? minH : 0, naturalMin)
                : Math.max(curH, Number.isFinite(minH) ? minH : 0, naturalMin);
            el.dataset.autoGrowMin = String(finalMinH || 0);
            if (Number.isFinite(maxH) && maxH > 0) {
                el.dataset.autoGrowMax = String(maxH);
            }
            el.dataset.autoGrowBound = '1';
        }
        const minHeight = parseFloat(el.dataset.autoGrowMin) || 0;
        const maxHeight = parseFloat(el.dataset.autoGrowMax) || 0;
        const hasValue = String(el.value || '').trim().length > 0;
        el.style.height = 'auto';
        let nextHeight = hasValue ? Math.max(el.scrollHeight, minHeight) : minHeight;
        if (maxHeight > 0 && nextHeight > maxHeight) {
            nextHeight = maxHeight;
            el.style.overflowY = 'auto';
        } else {
            el.style.overflowY = 'hidden';
        }
        el.style.height = nextHeight + 'px';
    }

    async function buildOfflineCrossModeMemoryText(contact, ctxLimit, providedMessages) {
        if (!contact) return '';
        try {
            var normalizedLimit = (typeof window.normalizeMiniApiContextLimit === 'function')
                ? window.normalizeMiniApiContextLimit(ctxLimit, 20)
                : (function(raw) {
                    var v = parseInt(raw, 10);
                    if (!isFinite(v) || isNaN(v)) v = 20;
                    if (v < 10) v = 10;
                    if (v > 200) v = 200;
                    return v;
                })(ctxLimit);
            var sourceMessages = Array.isArray(providedMessages) ? providedMessages : [];
            if (!sourceMessages.length && crossModeOfflineDb && crossModeOfflineDb.messages) {
                sourceMessages = await crossModeOfflineDb.messages.where('contactId').equals(contact.id).toArray();
            }
            var orderedMessages = orderMiniChatMessages(sourceMessages);
            var recentOfflineMsgs = orderedMessages.slice(-normalizedLimit);
            if (!recentOfflineMsgs.length) return '';
            var roleName = contact.roleName || '角色';
            return recentOfflineMsgs.map(function(m) {
                if (!m) return '';
                var sender = m.sender === 'me' ? '用户' : roleName;
                var text = String(m.content || '').trim();
                if (!text) return '';
                return sender + '：' + text;
            }).filter(function(line) {
                return !!line;
            }).join('\n');
        } catch (e) {
            console.warn('读取线下跨模式记忆失败', e);
            return '';
        }
    }

    async function buildOnlineCrossModeMemoryText(contact, ctxLimit, providedMessages) {
        if (!contact) return '';
        try {
            var normalizedLimit = (typeof window.normalizeMiniApiContextLimit === 'function')
                ? window.normalizeMiniApiContextLimit(ctxLimit, 20)
                : (function(raw) {
                    var v = parseInt(raw, 10);
                    if (!isFinite(v) || isNaN(v)) v = 20;
                    if (v < 10) v = 10;
                    if (v > 200) v = 200;
                    return v;
                })(ctxLimit);
            var sourceMessages = Array.isArray(providedMessages) ? providedMessages : [];
            if (!sourceMessages.length && chatListDb && chatListDb.messages) {
                sourceMessages = await chatListDb.messages.where('contactId').equals(contact.id).toArray();
            }
            var orderedMessages = orderMiniChatMessages(sourceMessages).filter(function(m) {
                return !!(m && m.source !== 'sms' && m.sender !== 'system' && !m.isSystemTip && !m.isRecalled);
            });
            var recentOnlineMsgs = orderedMessages.slice(-normalizedLimit);
            if (!recentOnlineMsgs.length) return '';
            var roleName = contact.roleName || '角色';
            return recentOnlineMsgs.map(function(m) {
                var sender = m.sender === 'me' ? '用户' : roleName;
                var text = typeof extractMsgPureText === 'function'
                    ? extractMsgPureText(m.content || '')
                    : String(m.content || '');
                text = String(text || '').trim();
                if (!text) return '';
                return sender + '：' + text;
            }).filter(function(line) {
                return !!line;
            }).join('\n');
        } catch (e) {
            console.warn('读取线上跨模式记忆失败', e);
            return '';
        }
    }

    async function buildSmsCrossModeMemoryText(contact, ctxLimit, providedMessages) {
        if (!contact) return '';
        try {
            var normalizedLimit = (typeof window.normalizeMiniApiContextLimit === 'function')
                ? window.normalizeMiniApiContextLimit(ctxLimit, 20)
                : (function(raw) {
                    var v = parseInt(raw, 10);
                    if (!isFinite(v) || isNaN(v)) v = 20;
                    if (v < 10) v = 10;
                    if (v > 200) v = 200;
                    return v;
                })(ctxLimit);
            var sourceMessages = Array.isArray(providedMessages) ? providedMessages : [];
            if (!sourceMessages.length && chatListDb && chatListDb.messages) {
                sourceMessages = await chatListDb.messages.where('contactId').equals(contact.id).toArray();
            }
            var orderedMessages = orderMiniChatMessages(sourceMessages).filter(function(m) {
                return !!(m && m.source === 'sms' && m.sender !== 'system' && !m.isSystemTip && !m.isRecalled);
            });
            var recentSmsMsgs = orderedMessages.slice(-normalizedLimit);
            if (!recentSmsMsgs.length) return '';
            var roleName = contact.roleName || '角色';
            return recentSmsMsgs.map(function(m) {
                var sender = m.sender === 'me' ? '用户' : roleName;
                var text = typeof extractMsgPureText === 'function'
                    ? extractMsgPureText(m.content || '')
                    : String(m.content || '');
                text = String(text || '').trim();
                if (!text) return '';
                return sender + '：' + text;
            }).filter(function(line) {
                return !!line;
            }).join('\n');
        } catch (e) {
            console.warn('读取信息跨模式记忆失败', e);
            return '';
        }
    }

    async function getMiniContactDisplayName(contact, fallbackName) {
        var name = _miniSafeText(fallbackName || (contact && contact.roleName), '角色');
        if (!contact || contact.id === undefined || contact.id === null) return name;
        try {
            var remark = await localforage.getItem('cd_settings_' + contact.id + '_remark');
            if (remark && remark !== '未设置') {
                var cleaned = String(remark).trim();
                if (cleaned) return cleaned;
            }
        } catch (e) {}
        return name;
    }

    async function getContactSummaryHistoryText(contactId) {
        if (!contactId) return '';
        try {
            var memoryEnabled = !!(await localforage.getItem('cd_settings_' + contactId + '_toggle_memory'));
            if (!memoryEnabled) return '';
            var history = await localforage.getItem('cd_settings_' + contactId + '_summary_history');
            if (!Array.isArray(history) || !history.length) return '';
            return history.map(function(item, index) {
                if (!item || !item.content) return '';
                var timeLabel = String(item.time || '未知时间');
                var msgCount = parseInt(item.msgCount, 10);
                var safeCount = (isFinite(msgCount) && msgCount > 0) ? msgCount : 0;
                return '【第' + (index + 1) + '次总结（' + timeLabel + '，共' + safeCount + '条消息）】\n' + String(item.content).trim();
            }).filter(function(block) {
                return !!block;
            }).join('\n\n');
        } catch (e) {
            console.warn('读取记忆总结失败', e);
            return '';
        }
    }

    async function buildContactWorldbookContextText(contact, recentTextSources, options) {
        if (!contact || !Array.isArray(contact.worldbooks) || contact.worldbooks.length === 0) return '';
        if (typeof db === 'undefined' || !db || !db.entries || typeof db.entries.where !== 'function') return '';
        const opt = (options && typeof options === 'object') ? options : {};
        const grouped = !!opt.grouped;
        try {
            const wbIds = contact.worldbooks.map(function(id) {
                return parseInt(id, 10);
            }).filter(function(id) {
                return !isNaN(id);
            });
            if (!wbIds.length) return '';
            const wbs = await db.entries.where('id').anyOf(wbIds).toArray();
            const priorityWeight = { high: 3, medium: 2, low: 1 };
            const wbOrderMap = new Map();
            wbIds.forEach(function(id, index) {
                wbOrderMap.set(id, index);
            });
            const sortedWbs = (Array.isArray(wbs) ? wbs : []).slice().sort(function(a, b) {
                const aPriority = priorityWeight[String(a && a.priority || 'medium')] || 2;
                const bPriority = priorityWeight[String(b && b.priority || 'medium')] || 2;
                if (aPriority !== bPriority) return bPriority - aPriority;
                const aOrder = wbOrderMap.has(a && a.id) ? wbOrderMap.get(a.id) : Number.MAX_SAFE_INTEGER;
                const bOrder = wbOrderMap.has(b && b.id) ? wbOrderMap.get(b.id) : Number.MAX_SAFE_INTEGER;
                if (aOrder !== bOrder) return aOrder - bOrder;
                const aUpdated = Number(a && a.updatedAt) || 0;
                const bUpdated = Number(b && b.updatedAt) || 0;
                return bUpdated - aUpdated;
            });
            const recentText = (Array.isArray(recentTextSources) ? recentTextSources : []).map(function(text) {
                return String(text || '').trim();
            }).filter(function(text) {
                return !!text;
            }).join('\n');
            const groupedContent = {
                before: [],
                middle: [],
                after: []
            };
            sortedWbs.forEach(function(wb) {
                if (!wb || !wb.content) return;
                if (wb.enabled === false) return;
                const injectPosition = wb.injectPosition === 'before' || wb.injectPosition === 'after' ? wb.injectPosition : 'middle';
                if (wb.activation === 'always') {
                    groupedContent[injectPosition].push(wb.content);
                    return;
                }
                if (wb.activation === 'keyword' && wb.keywords && recentText) {
                    const keywords = String(wb.keywords).split(/[,，]/).map(function(keyword) {
                        return keyword.trim();
                    }).filter(function(keyword) {
                        return !!keyword;
                    });
                    const hit = keywords.some(function(keyword) {
                        return recentText.includes(keyword);
                    });
                    if (hit) {
                        groupedContent[injectPosition].push(wb.content);
                    }
                }
            });
            const beforeText = groupedContent.before.join('\n');
            const middleText = groupedContent.middle.join('\n');
            const afterText = groupedContent.after.join('\n');
            if (grouped) {
                return {
                    before: beforeText,
                    middle: middleText,
                    after: afterText,
                    all: [beforeText, middleText, afterText].filter(function(text) { return !!text; }).join('\n')
                };
            }
            return [beforeText, middleText, afterText].filter(function(text) { return !!text; }).join('\n');
        } catch (e) {
            console.warn('读取世界书上下文失败', e);
            return grouped ? { before: '', middle: '', after: '', all: '' } : '';
        }
    }

    // 统一生成消息气泡的HTML
    function generateMsgHtml(msg, myAvatar, roleAvatar) {
        function _normalizeChatText(raw) {
            return String(raw || '')
                .replace(/\r\n?/g, '\n')
                .replace(/[ \t]+\n/g, '\n')
                .replace(/\n{3,}/g, '\n\n')
                .replace(/([^\n])\n(?=[^\n])/g, '$1 ');
        }

        if (msg.isRecalled) {
            const myName = document.getElementById('text-wechat-me-name') ? document.getElementById('text-wechat-me-name').textContent : '我';
            const name = msg.sender === 'me' ? myName : (activeChatContact.roleName || '角色');
            // 修复：多选模式下撤回提示也要可被选中删除，包裹 chat-msg-row 容器并附加 data-id
            const _isCheckedRecalled = selectedMsgIds.has(msg.id) ? 'checked' : '';
            return `<div class="chat-msg-row msg-system-row" data-id="${msg.id}" data-sender="${msg.sender}" onclick="if(multiSelectMode){toggleMsgCheck(${msg.id})}">
                <div class="msg-checkbox ${_isCheckedRecalled}" onclick="toggleMsgCheck(${msg.id})"></div>
                <div class="msg-recalled-tip" style="flex:1;">${name} 撤回了一条消息 <span onclick="event.stopPropagation();viewRecalledMsg(${msg.id})">查看</span></div>
            </div>`;
        }
        // 系统提示消息（红包/转账状态提示等）单独渲染，不走气泡逻辑
        if (msg.isSystemTip) {
            // 修复掉格：isSystemTip 消息的 content 是 JSON 字符串，需解析出 content 字段
            let _sysTipText = msg.content;
            try {
                const _sysParsed = JSON.parse(msg.content);
                if (_sysParsed && _sysParsed.content) _sysTipText = _sysParsed.content;
            } catch(e) {}
            // 修复：多选模式下系统提示也要可被选中删除，包裹 chat-msg-row 容器并附加 data-id
            const _isCheckedSys = selectedMsgIds.has(msg.id) ? 'checked' : '';
            return `<div class="chat-msg-row msg-system-row" data-id="${msg.id}" data-sender="${msg.sender}" onclick="if(multiSelectMode){toggleMsgCheck(${msg.id})}">
                <div class="msg-checkbox ${_isCheckedSys}" onclick="toggleMsgCheck(${msg.id})"></div>
                <div class="msg-recalled-tip" style="flex:1;">${_sysTipText}</div>
            </div>`;
        }
        // 拉黑申请消息：使用专用渲染函数（带红色感叹号徽章）
        try {
            const _chk = JSON.parse(msg.content);
            if (_chk && _chk.type === 'block_apply') {
                return generateBlockApplyMsgHtml(msg, myAvatar, roleAvatar);
            }
        } catch(e) {}
        const isMe = msg.sender === 'me';
        const avatar = getSafeAvatarSrc(isMe ? myAvatar : roleAvatar);
        const msgClass = isMe ? 'msg-right' : 'msg-left';
        let statusHtml = '';
        let quoteHtml = '';
        if (msg.quoteText) {
            try {
                // 尝试解析为 JSON 对象（新格式）
                const qData = JSON.parse(msg.quoteText);
                quoteHtml = `
                    <div class="msg-quote-ref">
                        <div class="msg-quote-header">
                            <span class="msg-quote-name">${qData.name}</span>
                            <span class="msg-quote-time">${qData.time}</span>
                        </div>
                        <div class="msg-quote-content">${qData.content}</div>
                    </div>
                `;
            } catch (e) {
                // 如果解析失败，说明是以前存的纯文本旧数据，兼容显示
                quoteHtml = `
                    <div class="msg-quote-ref">
                        <div class="msg-quote-content">${msg.quoteText}</div>
                    </div>
                `;
            }
        }
        const isChecked = selectedMsgIds.has(msg.id) ? 'checked' : '';
        // 安全转义并处理换行：将纯文本中的 \n 转为 <br>，防止 XSS 同时保留换行格式
        function _safeTextHtml(raw) {
            if (!raw) return '';
            const normalized = _normalizeChatText(raw);
            // 先转义 HTML 特殊字符，再把换行转为 <br>
            return normalized
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/\n/g, '<br>');
        }
        let msgBodyHtml = '';
        const translationMatch = (typeof msg.content === 'string')
            ? msg.content.match(/^\s*<div class="msg-original-text">([\s\S]*?)<\/div>\s*<div class="msg-translate-divider"><\/div>\s*<div class="msg-translated-text">([\s\S]*?)<\/div>\s*$/)
            : null;
        if (translationMatch) {
            const originalText = _safeTextHtml(translationMatch[1]);
            const translatedText = _safeTextHtml(translationMatch[2]);
            msgBodyHtml = `<div class="msg-text-body"><div class="msg-original-text">${originalText}</div><div class="msg-translate-divider"></div><div class="msg-translated-text">${translatedText}</div></div>`;
        } else {
            msgBodyHtml = `<div class="msg-text-body">${_safeTextHtml(msg.content)}</div>`;
        }
        let isCameraMsg = false;
        let cameraDesc = '';
        let isImageMsg = false;
        let imageBase64 = '';
        let isEmoticonMsg = false;
        let emoticonUrl = '';
        let isLocationMsg = false;
        let locationAddress = '';
        let locationDistance = '';
        let isVoiceMsg = false;
        let voiceText = '';
        let voiceSeconds = 0;
        const structuredMsg = parseMiniStructuredPayload(msg.content);
        if (structuredMsg) {
            if (structuredMsg.type === 'voice_message') {
                isVoiceMsg = true;
                voiceText = structuredMsg.transcript || '';
                voiceSeconds = Math.max(1, structuredMsg.durationSec || 1);
            } else if (structuredMsg.type === 'red_packet') {
                statusHtml = '';
                const rpAmount = structuredMsg.amount || '0.00';
                const rpDesc = structuredMsg.memo || '恭喜发财，大吉大利';
                const rpStatus = structuredMsg.status || 'unclaimed';
                const rpStatusLabel = rpStatus === 'claimed' ? (isMe ? '已被领取' : '已领取') : '待领取';
                const rpStatusColor = rpStatus === 'claimed' ? '#bbb' : '#e8534a';
                const roleName = _miniEscapeAttr(activeChatContact ? (activeChatContact.roleName || '对方') : '对方');
                msgBodyHtml = `
                    <div class="card-wrapper" data-no-bubble="1">
                        <div class="chat-red-packet-card${rpStatus === 'claimed' ? ' rp-claimed' : ''}" data-rp-amount="${rpAmount}" data-rp-desc="${_miniEscapeAttr(rpDesc)}" data-rp-status="${rpStatus}" data-rp-role="${isMe ? 'me' : 'role'}" data-rp-rname="${roleName}" onclick="openRpClaimModal(this, this.dataset.rpAmount, this.dataset.rpDesc, this.dataset.rpStatus, this.dataset.rpRole, this.dataset.rpRname, ${msg.id})">
                            <div class="rp-card-icon-area">
                                <div class="rp-card-icon-wrap">
                                    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="rgba(100,100,100,0.55)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
                                        <rect x="3" y="4" width="18" height="16" rx="2" ry="2"></rect>
                                        <line x1="3" y1="10" x2="21" y2="10"></line>
                                        <circle cx="12" cy="10" r="2"></circle>
                                    </svg>
                                </div>
                                <div class="rp-card-text-group">
                                    <div class="rp-card-amount">¥ ${rpAmount}</div>
                                    <div class="rp-card-desc">${_safeTextHtml(rpDesc)}</div>
                                </div>
                            </div>
                            <div class="rp-card-divider"></div>
                            <div class="rp-card-bottom">
                                <span class="rp-card-status" style="color:${rpStatusColor};">${rpStatusLabel}</span>
                                <span class="rp-card-brand">WeChat红包</span>
                            </div>
                        </div>
                    </div>
                `;
            } else if (structuredMsg.type === 'transfer') {
                statusHtml = '';
                const tfAmount = structuredMsg.amount || '0.00';
                const tfDesc = structuredMsg.memo || '转账';
                const tfStatus = structuredMsg.status || 'pending';
                const tfStatusLabel = tfStatus === 'refunded' ? '已退回' : (tfStatus === 'received' ? '已收款' : '待收款');
                const tfStatusColor = tfStatus === 'refunded' ? '#bbb' : (tfStatus === 'received' ? '#27ae60' : '#1a6fb5');
                const roleName2 = _miniEscapeAttr(activeChatContact ? (activeChatContact.roleName || '对方') : '对方');
                msgBodyHtml = `
                    <div class="card-wrapper" data-no-bubble="1">
                        <div class="chat-transfer-card${tfStatus !== 'pending' ? ' tf-received' : ''}" data-tf-amount="${tfAmount}" data-tf-desc="${_miniEscapeAttr(tfDesc)}" data-tf-status="${tfStatus}" data-tf-role="${isMe ? 'me' : 'role'}" data-tf-rname="${roleName2}" onclick="openTfActionModal(this, this.dataset.tfAmount, this.dataset.tfDesc, this.dataset.tfStatus, this.dataset.tfRole, this.dataset.tfRname)">
                            <div class="tf-card-icon-area">
                                <div class="tf-card-icon-wrap">
                                    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="rgba(100,100,100,0.55)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
                                        <polyline points="16 3 21 3 21 8"></polyline>
                                        <line x1="4" y1="20" x2="21" y2="3"></line>
                                        <polyline points="21 16 21 21 16 21"></polyline>
                                        <line x1="15" y1="15" x2="21" y2="21"></line>
                                        <line x1="4" y1="4" x2="9" y2="9"></line>
                                    </svg>
                                </div>
                                <div class="tf-card-text-group">
                                    <div class="tf-card-amount">¥ ${tfAmount}</div>
                                    <div class="tf-card-desc">${_safeTextHtml(tfDesc)}</div>
                                </div>
                            </div>
                            <div class="tf-card-divider"></div>
                            <div class="tf-card-bottom">
                                <span class="tf-card-status" style="color:${tfStatusColor};">${tfStatusLabel}</span>
                                <span class="tf-card-brand">WeChat转账</span>
                            </div>
                        </div>
                    </div>
                `;
            } else if (structuredMsg.type === 'gift_delivery') {
                statusHtml = '';
                const giftTitle = structuredMsg.items.slice(0, 2).map(function(item) {
                    return item.name + (item.qty > 1 ? (' ×' + item.qty) : '');
                }).join(' · ');
                const giftStatusLabel = structuredMsg.status === 'received' ? '已签收' : '待查收';
                msgBodyHtml = `
                    <div class="card-wrapper" data-no-bubble="1">
                        <div class="chat-special-card special-gift-card">
                            <div class="special-card-header">
                                <div class="special-card-icon">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">
                                        <polyline points="20 12 20 22 4 22 4 12"></polyline>
                                        <rect x="2" y="7" width="20" height="5"></rect>
                                        <line x1="12" y1="22" x2="12" y2="7"></line>
                                        <path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"></path>
                                        <path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"></path>
                                    </svg>
                                </div>
                                <div class="special-card-meta">
                                    <div class="special-card-kicker">礼物清单</div>
                                    <div class="special-card-title">${_safeTextHtml(giftTitle || '给你准备了礼物')}</div>
                                </div>
                            </div>
                            <div class="special-card-note">${_safeTextHtml(structuredMsg.note || '送你一份心意')}</div>
                            <div class="special-card-footer">
                                <span>${structuredMsg.items.length} 件心意</span>
                                <span>${giftStatusLabel}</span>
                            </div>
                        </div>
                    </div>
                `;
            } else if (structuredMsg.type === 'takeout_delivery') {
                statusHtml = '';
                const takeoutTitle = structuredMsg.items.slice(0, 2).map(function(item) {
                    return item.name + (item.qty > 1 ? (' ×' + item.qty) : '');
                }).join(' · ');
                const takeoutStatusMap = {
                    preparing: '商家备餐中',
                    delivering: '正在配送',
                    arrived: '已送达'
                };
                msgBodyHtml = `
                    <div class="card-wrapper" data-no-bubble="1">
                        <div class="chat-special-card special-takeout-card">
                            <div class="special-card-header">
                                <div class="special-card-icon">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M7 10h10"></path>
                                        <path d="M7 14h10"></path>
                                        <path d="M5 6h14l-1 12a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6z"></path>
                                        <path d="M9 6V4a3 3 0 0 1 6 0v2"></path>
                                    </svg>
                                </div>
                                <div class="special-card-meta">
                                    <div class="special-card-kicker">${_safeTextHtml(structuredMsg.restaurant || '暖心外卖')}</div>
                                    <div class="special-card-title">${_safeTextHtml(takeoutTitle || '给你点了外卖')}</div>
                                </div>
                            </div>
                            <div class="special-card-note">${_safeTextHtml(structuredMsg.note || '记得趁热吃')}</div>
                            <div class="special-card-footer">
                                <span>合计 ¥ ${structuredMsg.total || '0.00'}</span>
                                <span>${_safeTextHtml(takeoutStatusMap[structuredMsg.status] || structuredMsg.eta || '尽快送达')}</span>
                            </div>
                        </div>
                    </div>
                `;
            } else if (structuredMsg.type === 'call_invite') {
                statusHtml = '';
                const callModeLabel = structuredMsg.mode === 'video' ? '视频通话' : '语音通话';
                const callStatusMap = {
                    ringing: '等待接听',
                    connected: '已接通',
                    ended: '通话结束',
                    missed: '未接听',
                    declined: '已拒绝'
                };
                msgBodyHtml = `
                    <div class="card-wrapper" data-no-bubble="1">
                        <div class="chat-special-card special-call-card">
                            <div class="special-card-header">
                                <div class="special-card-icon">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">
                                        ${structuredMsg.mode === 'video'
                                            ? '<polygon points="23 7 16 12 23 17 23 7"></polygon><rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect>'
                                            : '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>'}
                                    </svg>
                                </div>
                                <div class="special-card-meta">
                                    <div class="special-card-kicker">${callModeLabel}</div>
                                    <div class="special-card-title">${_safeTextHtml(structuredMsg.note || '发起通话邀请')}</div>
                                </div>
                            </div>
                            <div class="special-card-note">${callStatusMap[structuredMsg.status] || '等待接听'}</div>
                            <div class="special-card-footer">
                                <span>通话邀请</span>
                                <span>${callStatusMap[structuredMsg.status] || '等待接听'}</span>
                            </div>
                        </div>
                    </div>
                `;
            } else if (structuredMsg.type === 'forward_bundle') {
                statusHtml = '';
                const forwardMeName = getMiniProfileNickname(structuredMsg.sourceUserName || '我');
                const forwardPeerName = _miniSafeText(structuredMsg.sourceContactName, '对方');
                const forwardTitle = forwardMeName + '和' + forwardPeerName + '的聊天记录';
                const forwardPreviewLines = (Array.isArray(structuredMsg.previewLines) ? structuredMsg.previewLines : []).slice(0, 4);
                const previewHtml = (forwardPreviewLines.length ? forwardPreviewLines : ['聊天记录']).map(function(line) {
                    return '<div class="chat-forward-line">' + _safeTextHtml(line) + '</div>';
                }).join('');
                const encodedMsgId = encodeURIComponent(String(msg.id || ''));
                msgBodyHtml = `
                    <div class="card-wrapper" data-no-bubble="1">
                        <div class="chat-forward-card" data-forward-msg-id="${encodedMsgId}">
                            <div class="chat-forward-title">${_safeTextHtml(forwardTitle)}</div>
                            <div class="chat-forward-preview">${previewHtml}</div>
                            <div class="chat-forward-divider"></div>
                            <div class="chat-forward-footer">聊天记录</div>
                        </div>
                    </div>
                `;
            }
        } else {
            try {
                const parsed = JSON.parse(msg.content);
                if (parsed && parsed.type === 'camera') {
                    isCameraMsg = true;
                    cameraDesc = parsed.content || '';
                } else if (parsed && parsed.type === 'image') {
                    isImageMsg = true;
                    imageBase64 = parsed.content || '';
                } else if (parsed && parsed.type === 'emoticon') {
                    isEmoticonMsg = true;
                    emoticonUrl = parsed.content || '';
                } else if (parsed && parsed.type === 'location') {
                    isLocationMsg = true;
                    locationAddress = parsed.address || '未知位置';
                    locationDistance = parsed.distance || '';
                }
            } catch(e) {
                // 兼容旧的 [CAMERA] 格式
                if (msg.content && msg.content.startsWith('[CAMERA]')) {
                    isCameraMsg = true;
                    cameraDesc = msg.content.substring(8);
                }
                // 兼容旧的纯文本转账/红包格式，统一匹配所有可能的前缀变体：
                // 💰 [微信转账] 向你转账 ¥200.00
                // 【转账：测试专用】
                // [转账] 向你转账 ¥12.00
                else if (msg.content && (
                    msg.content.startsWith('💰') ||
                    msg.content.startsWith('【转账') ||
                    msg.content.startsWith('[转账]') ||
                    /^\[微信转账\]/.test(msg.content)
                )) {
                    statusHtml = '';
                    // 统一清理各种前缀后提取剩余文本
                    let tfText = msg.content
                        .replace(/^💰\s*/, '')
                        .replace(/^\[微信转账\]\s*/,'')
                        .replace(/^【转账[：:][^】]*】\s*/,'')
                        .replace(/^\[转账\]\s*/,'')
                        .trim();
                    // 尝试提取金额（¥ 后面的数字，或直接的纯数字）
                    const amtMatch = tfText.match(/¥\s*([\d,]+(?:\.\d+)?)/) || tfText.match(/^([\d,]+(?:\.\d+)?)/);
                    const tfAmount = amtMatch ? amtMatch[1].replace(/,/g, '') : '0.00';
                    // 提取备注：去掉"向你转账"和金额部分后剩余内容，或用原始文本
                    let tfDesc = tfText
                        .replace(/向你转账\s*/g, '')
                        .replace(/¥\s*[\d,]+(?:\.\d+)?/, '')
                        .replace(/^[\d,]+(?:\.\d+)?/, '')
                        .trim();
                    if (!tfDesc) tfDesc = '转账';
                    const roleName2 = activeChatContact ? (activeChatContact.roleName || '对方') : '对方';
                    msgBodyHtml = `
                        <div class="card-wrapper" data-no-bubble="1">
                            <div class="chat-transfer-card" data-tf-amount="${tfAmount}" data-tf-desc="${_miniEscapeAttr(tfDesc)}" data-tf-status="pending" data-tf-role="${isMe ? 'me' : 'role'}" data-tf-rname="${_miniEscapeAttr(roleName2)}" onclick="openTfActionModal(this, this.dataset.tfAmount, this.dataset.tfDesc, this.dataset.tfStatus, this.dataset.tfRole, this.dataset.tfRname)">
                                <div class="tf-card-top">
                                    <div class="tf-card-icon">
                                        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="rgba(255,255,255,0.95)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                            <path d="M12 2L2 7l10 5 10-5-10-5z"></path>
                                            <path d="M2 17l10 5 10-5"></path>
                                            <path d="M2 12l10 5 10-5"></path>
                                        </svg>
                                    </div>
                                    <div class="tf-card-info">
                                        <div class="tf-card-amount">¥ ${tfAmount}</div>
                                        <div class="tf-card-desc">${tfDesc}</div>
                                    </div>
                                </div>
                                <div class="tf-card-divider"></div>
                                <div class="tf-card-bottom">
                                    <span class="tf-card-status" style="color:#1a6fb5;">待收款</span>
                                    <span class="tf-card-brand">转账</span>
                                </div>
                            </div>
                        </div>
                    `;
                }
                // 兼容旧的纯文本红包格式，统一匹配所有可能的前缀变体：
                // 🧧 [恭喜发财，大吉大利]
                // 【红包：测试专用】
                // [红包] ¥52.00
                else if (msg.content && (
                    msg.content.startsWith('🧧') ||
                    msg.content.startsWith('【红包') ||
                    msg.content.startsWith('[红包]')
                )) {
                    statusHtml = '';
                    // 统一清理各种红包前缀后提取剩余文本
                    let rpText = msg.content
                        .replace(/^🧧\s*/, '')
                        .replace(/^【红包[：:][^】]*】\s*/,'')
                        .replace(/^\[红包\]\s*/,'')
                        .trim();
                    // 尝试提取金额（¥ 后面的数字，或直接的纯数字）
                    const amtMatch2 = rpText.match(/¥\s*([\d,]+(?:\.\d+)?)/) || rpText.match(/^([\d,]+(?:\.\d+)?)/);
                    const rpAmount = amtMatch2 ? amtMatch2[1].replace(/,/g, '') : '0.00';
                    // 提取描述：优先取方括号内的文字（如 [恭喜发财，大吉大利]），否则用剩余文本（去掉数字部分）
                    const descInBracket = rpText.match(/^\[([^\]]+)\]/);
                    let rpDesc = descInBracket
                        ? descInBracket[1]
                        : (rpText.replace(/¥\s*[\d,]+(?:\.\d+)?/, '').replace(/^[\d,]+(?:\.\d+)?/, '').trim() || '恭喜发财，大吉大利');
                    if (!rpDesc) rpDesc = '恭喜发财，大吉大利';
                    const roleName = activeChatContact ? (activeChatContact.roleName || '对方') : '对方';
                    msgBodyHtml = `
                        <div class="card-wrapper" data-no-bubble="1">
                            <div class="chat-red-packet-card" data-rp-amount="${rpAmount}" data-rp-desc="${_miniEscapeAttr(rpDesc)}" data-rp-status="unclaimed" data-rp-role="${isMe ? 'me' : 'role'}" data-rp-rname="${_miniEscapeAttr(roleName)}" onclick="openRpClaimModal(this, this.dataset.rpAmount, this.dataset.rpDesc, this.dataset.rpStatus, this.dataset.rpRole, this.dataset.rpRname, ${msg.id})">
                                <div class="rp-card-top">
                                    <div class="rp-card-icon">
                                        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="rgba(255,255,255,0.95)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                            <rect x="2" y="7" width="20" height="14" rx="3" ry="3"></rect>
                                            <path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"></path>
                                            <line x1="12" y1="12" x2="12" y2="16"></line>
                                            <line x1="10" y1="14" x2="14" y2="14"></line>
                                        </svg>
                                    </div>
                                    <div class="rp-card-info">
                                        <div class="rp-card-amount">¥ ${rpAmount}</div>
                                        <div class="rp-card-desc">${rpDesc}</div>
                                    </div>
                                </div>
                                <div class="rp-card-divider"></div>
                                <div class="rp-card-bottom">
                                    <span class="rp-card-status" style="color:#e8534a;">待领取</span>
                                    <span class="rp-card-brand">红包</span>
                                </div>
                            </div>
                        </div>
                    `;
                }
            }
        }
        if (isCameraMsg) {
            statusHtml = ''; // 隐藏双✓
            msgBodyHtml = `
                <div class="chat-photo-card" onclick="this.classList.toggle('flipped')">
                    <div class="chat-photo-front">
                        <svg viewBox="0 0 24 24" width="40" height="40" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path><circle cx="12" cy="13" r="4"></circle></svg>
                    </div>
                    <div class="chat-photo-back">${cameraDesc}</div>
                </div>
            `;
        } else if (isImageMsg || isEmoticonMsg) {
            statusHtml = ''; // 隐藏双✓
            let imgSrc = isImageMsg ? imageBase64 : emoticonUrl;
            msgBodyHtml = `
                <div class="chat-photo-card" style="border: none; background: transparent; box-shadow: none; height: auto; max-width: 140px;">
                    <img src="${imgSrc}" style="width: 100%; height: auto; object-fit: contain; border-radius: 8px;">
                </div>
            `;
        } else if (isLocationMsg) {
            statusHtml = ''; // 隐藏双✓
            msgBodyHtml = `
                <div class="chat-location-card">
                    <div class="chat-location-header">
                        <div class="chat-location-address">${locationAddress}</div>
                        <div class="chat-location-distance">${locationDistance}</div>
                    </div>
                    <div class="chat-location-map">
                        <div class="chat-location-shadow"></div>
                        <div class="chat-location-pin"></div>
                    </div>
                </div>
            `;
        } else if (isVoiceMsg) {
            statusHtml = ''; // 隐藏双✓，保持纯净
            msgBodyHtml = `
                <div class="voice-msg-container" onclick="toggleVoiceText(this)">
                    <div class="voice-bubble-top">
                        <div class="voice-waves paused">
                            <div class="voice-wave"></div>
                            <div class="voice-wave"></div>
                            <div class="voice-wave"></div>
                            <div class="voice-wave"></div>
                            <div class="voice-wave"></div>
                        </div>
                        <div class="voice-duration">${voiceSeconds}"</div>
                    </div>
                    <div class="voice-expand-area">
                        <div class="voice-divider"></div>
                        <div class="voice-text-content">${voiceText}</div>
                    </div>
                </div>
            `;
        }
        // 拉黑状态下角色消息气泡右上角显示红色感叹号（发送失败标志）
        const _showBlockedBadge = !isMe && activeChatContact && activeChatContact.blocked;
        const _blockedBadgeHtml = _showBlockedBadge ? `<div style="position:absolute;top:-6px;right:-6px;width:18px;height:18px;border-radius:50%;background:#e74c3c;display:flex;align-items:center;justify-content:center;font-size:11px;color:#fff;font-weight:700;box-shadow:0 2px 6px rgba(231,76,60,0.5);">!</div>` : '';
        const _isBubblelessMsg = isCameraMsg || isImageMsg || isEmoticonMsg || isLocationMsg || !!(structuredMsg && ['red_packet', 'transfer', 'gift_delivery', 'takeout_delivery', 'call_invite', 'forward_bundle'].includes(structuredMsg.type));
        return `
            <div class="chat-msg-row ${msgClass}" data-id="${msg.id}" data-sender="${msg.sender}">
                <div class="msg-checkbox ${isChecked}" onclick="toggleMsgCheck(${msg.id})"></div>
                <div class="chat-msg-avatar"><img src="${avatar}" loading="lazy" decoding="async" onerror="this.onerror=null;this.src='${DEFAULT_AVATAR_DATA_URI}';"></div>

                <div class="msg-bubble-wrapper" style="position:relative;">
                    <div class="chat-msg-content msg-content-touch" style="${_isBubblelessMsg ? 'background:transparent; box-shadow:none; padding:0;' : ''}">
                        ${quoteHtml}
                        ${msgBodyHtml}
                        ${statusHtml}
                    </div>
                    <div class="chat-timestamp" style="${_isBubblelessMsg ? 'display:none;' : ''}">${msg.timeStr}</div>
                    ${_blockedBadgeHtml}
                </div>
            </div>
        `;
    }

    async function openWechatForwardCardDetail(encodedMsgId) {
        try {
            let msgIdRaw = String(encodedMsgId || '').trim();
            try {
                msgIdRaw = decodeURIComponent(msgIdRaw);
            } catch (e) {}
            if (!msgIdRaw) {
                return;
            }
            let msg = await chatListDb.messages.get(msgIdRaw);
            if (!msg) {
                const msgIdNum = Number(msgIdRaw);
                if (Number.isFinite(msgIdNum)) {
                    msg = await chatListDb.messages.get(msgIdNum);
                }
            }
            if (!msg) {
                return;
            }
            const structured = parseMiniStructuredPayload(msg.content);
            if (!structured) {
                return;
            }
            if (structured.type !== 'forward_bundle') {
                return;
            }

            let sourceContact = null;
            if (structured.sourceContactId) {
                try {
                    sourceContact = await contactDb.contacts.get(structured.sourceContactId);
                } catch (e) {
                    sourceContact = null;
                }
            }

            const recordMeName = getMiniProfileNickname(structured.sourceUserName || '我');
            const sourceContactBaseName = structured.sourceContactName || (sourceContact && sourceContact.roleName) || '对方';
            const sourceContactName = await getMiniContactDisplayName(sourceContact, sourceContactBaseName);
            const myAvatar = getSafeAvatarSrc(
                sourceContact && sourceContact.userAvatar
                    ? sourceContact.userAvatar
                    : (activeChatContact && activeChatContact.userAvatar ? activeChatContact.userAvatar : '')
            );
            const roleAvatar = getSafeAvatarSrc(
                sourceContact && sourceContact.roleAvatar
                    ? sourceContact.roleAvatar
                    : (activeChatContact && activeChatContact.roleAvatar ? activeChatContact.roleAvatar : '')
            );

            const rows = Array.isArray(structured.messages) ? structured.messages : [];
            const currentChatDisplayName = activeChatContact
                ? await getMiniContactDisplayName(activeChatContact, activeChatContact.roleName || '角色')
                : '';
            const isSameChatRecord = !!(
                activeChatContact
                && structured.sourceContactId
                && String(activeChatContact.id) === String(structured.sourceContactId)
            );
            renderWechatRecordDetailPage({
                titleElementId: 'wechat-forward-detail-title',
                bodyElementId: 'wechat-forward-detail-body',
                heading: recordMeName + '和' + sourceContactName + '的聊天记录',
                sourceLabel: '转发聊天记录',
                currentSceneLabel: '当前所在会话',
                currentSceneValue: isSameChatRecord ? '当前会话就是这段原聊天' : (currentChatDisplayName ? (recordMeName + ' ↔ ' + currentChatDisplayName) : ''),
                recordLabel: structured.note || structured.title || '',
                messages: rows,
                meName: recordMeName,
                peerName: sourceContactName,
                myAvatar: myAvatar,
                peerAvatar: roleAvatar
            });

            if (typeof window.syncWechatOverlayStack === 'function') {
                window.syncWechatOverlayStack(['wechat-app', 'wechat-forward-detail-page']);
            } else {
                const page = document.getElementById('wechat-forward-detail-page');
                if (page) page.style.display = 'flex';
                const chatWin = document.getElementById('chat-window');
                if (chatWin) chatWin.style.display = 'none';
            }
        } catch (e) {
            console.error('打开转发聊天记录详情失败', e);
        }
    }

    function closeWechatForwardDetailPage() {
        if (typeof window.syncWechatOverlayStack === 'function') {
            window.syncWechatOverlayStack(['wechat-app', 'chat-window']);
        } else {
            const page = document.getElementById('wechat-forward-detail-page');
            if (page) page.style.display = 'none';
            const chatWin = document.getElementById('chat-window');
            if (chatWin) chatWin.style.display = 'flex';
        }
    }
    window.openWechatForwardCardDetail = openWechatForwardCardDetail;
    window.closeWechatForwardDetailPage = closeWechatForwardDetailPage;

    // ====== 聊天分页：每页显示消息数 ======
    const CHAT_PAGE_SIZE = 20;

    async function enterChatWindow(contactId) {
        const contact = await contactDb.contacts.get(contactId);
        if (!contact) return;
        activeChatContact = contact;
        await _loadChatBeautifyConfig({ kind: 'role', contactId: contact.id }, true);
        const win = document.getElementById('chat-window');
        if (typeof window.syncWechatOverlayStack === 'function') {
            window.syncWechatOverlayStack(['wechat-app', 'chat-window']);
        } else if (win) {
            win.style.display = 'flex';
        }
        // 修复：优先使用备注名，没有备注才用 roleName
        let _chatDisplayName = contact.roleName || '角色';
        try {
            const _remark = await localforage.getItem('cd_settings_' + contact.id + '_remark');
            if (_remark && _remark !== '未设置') _chatDisplayName = _remark;
        } catch(e) {}
        const chatTitleEl = document.getElementById('chat-current-name');
        if (chatTitleEl) {
            chatTitleEl.textContent = _chatDisplayName;
            if (typeof window.setMiniHeaderFixedSubtitle === 'function') {
                window.setMiniHeaderFixedSubtitle(chatTitleEl, contact.roleName || _chatDisplayName, 'CHAT');
            }
        }
        const container = document.getElementById('chat-msg-container');
        container.innerHTML = ''; 
        try {
            // 【聊天隔离】WeChat聊天窗口只显示 source==='wechat' 或无source（旧数据兼容）的消息
            // 注意：source==='sms' 的消息绝对不允许出现在WeChat窗口中
            const allMessages = orderMiniChatMessages(await chatListDb.messages.where('contactId').equals(contactId).toArray());
            const messages = allMessages.filter(m => m.source !== 'sms');
            const myAvatar = getSafeAvatarSrc(contact.userAvatar);
            const roleAvatar = getSafeAvatarSrc(contact.roleAvatar);
            
            // ====== 聊天分页：只显示最后一页，其余折叠 ======
            const totalCount = messages.length;
            const pageSize = CHAT_PAGE_SIZE;
            let htmlStr = '';

            if (totalCount > pageSize) {
                // 有历史消息需要折叠
                const hiddenCount = totalCount - pageSize;
                const visibleMessages = messages.slice(totalCount - pageSize);
                // 插入"查看历史记录"提示条
                htmlStr += `<div id="chat-history-banner" style="text-align:center; padding:10px 0 6px; cursor:pointer;" onclick="expandChatHistory('${contactId}')">
                    <span style="font-size:11px; color:#aaa; background:rgba(0,0,0,0.05); padding:4px 14px; border-radius:20px; letter-spacing:0.3px;">查看历史记录（${hiddenCount}条）&nbsp;▴</span>
                </div>`;
                visibleMessages.forEach(msg => {
                    htmlStr += generateMsgHtml(msg, myAvatar, roleAvatar);
                });
            } else {
                // 消息数不超过一页，全部显示
                messages.forEach(msg => {
                    htmlStr += generateMsgHtml(msg, myAvatar, roleAvatar);
                });
            }

            container.innerHTML = htmlStr;
            
            bindMsgEvents();
            
            // 性能优化：使用 requestAnimationFrame 保证渲染完成后再滚动
            requestAnimationFrame(() => {
                container.scrollTop = container.scrollHeight;
            });
            setTimeout(() => { container.scrollTop = container.scrollHeight; }, 300);
        } catch (e) {
            console.error("加载历史消息失败", e);
        }
        const input = document.getElementById('chat-input-main');
        input.value = '';
        autoGrowTextarea(input);
        hideChatExtPanel();
        exitMultiSelectMode(); // 重置多选状态
        cancelQuote(); // 重置引用状态
        if (typeof syncActiveChatReplyUi === 'function') {
            await syncActiveChatReplyUi();
        }
        // 进入聊天窗口时同步角色拉黑横幅状态
        updateWechatBlockedBanner();
    }

    // ====== 展开全部历史聊天记录 ======
    async function expandChatHistory(contactId) {
        if (!activeChatContact) return;
        const contact = activeChatContact;
        const container = document.getElementById('chat-msg-container');
        const myAvatar = getSafeAvatarSrc(contact.userAvatar);
        const roleAvatar = getSafeAvatarSrc(contact.roleAvatar);
        try {
            const messages = orderMiniChatMessages(await chatListDb.messages.where('contactId').equals(contactId || contact.id).toArray()).filter(function(msg) {
                return msg && msg.source !== 'sms';
            });
            // 移除历史记录提示条
            const banner = document.getElementById('chat-history-banner');
            if (banner) banner.remove();
            // 获取当前已显示的第一条消息的id（用于在前面插入历史）
            const firstRow = container.querySelector('.chat-msg-row');
            const firstMsgId = firstRow ? parseInt(firstRow.getAttribute('data-id')) : null;
            // 找出未显示的历史消息
            let hiddenMessages;
            if (firstMsgId) {
                hiddenMessages = messages.filter(m => m.id < firstMsgId);
            } else {
                hiddenMessages = messages;
            }
            if (hiddenMessages.length === 0) return;
            // 生成历史消息HTML并插入到容器最前面
            let historyHtml = '';
            hiddenMessages.forEach(msg => {
                historyHtml += generateMsgHtml(msg, myAvatar, roleAvatar);
            });
            container.insertAdjacentHTML('afterbegin', historyHtml);
            bindMsgEvents();
        } catch(e) {
            console.error("展开历史消息失败", e);
        }
    }

    // 隐藏聊天扩展面板与表情面板
    function hideChatExtPanel() {
        const extPanel = document.getElementById('chat-ext-panel');
        const extBtn = document.getElementById('chat-ext-btn');
        if (extPanel) extPanel.classList.remove('show');
        if (extBtn) extBtn.classList.remove('active');
        
        const emojiPanel = document.getElementById('chat-emoji-panel');
        const emojiBtn = document.getElementById('chat-emoji-btn');
        if (emojiPanel) emojiPanel.classList.remove('show');
        if (emojiBtn) emojiBtn.classList.remove('active');
    }

    function toggleChatExtPanel() {
        const extPanel = document.getElementById('chat-ext-panel');
        const extBtn = document.getElementById('chat-ext-btn');
        const emojiPanel = document.getElementById('chat-emoji-panel');
        const emojiBtn = document.getElementById('chat-emoji-btn');
        // 先收起表情面板
        if (emojiPanel) { emojiPanel.classList.remove('show'); }
        if (emojiBtn) { emojiBtn.classList.remove('active'); }
        if (!extPanel) return;
        if (extPanel.classList.contains('show')) {
            extPanel.classList.remove('show');
            if (extBtn) extBtn.classList.remove('active');
        } else {
            extPanel.classList.add('show');
            if (extBtn) extBtn.classList.add('active');
        }
    }

    let currentChatEmojiGroupId = null;
    async function toggleChatEmojiPanel() {
        const emojiPanel = document.getElementById('chat-emoji-panel');
        const emojiBtn = document.getElementById('chat-emoji-btn');
        const extPanel = document.getElementById('chat-ext-panel');
        const extBtn = document.getElementById('chat-ext-btn');
        // 先收起扩展面板
        if (extPanel) { extPanel.classList.remove('show'); }
        if (extBtn) { extBtn.classList.remove('active'); }
        if (!emojiPanel) return;
        if (emojiPanel.classList.contains('show')) {
            emojiPanel.classList.remove('show');
            if (emojiBtn) emojiBtn.classList.remove('active');
        } else {
            await initEmoticonDB();
            emojiPanel.classList.add('show');
            if (emojiBtn) emojiBtn.classList.add('active');
            await loadChatEmojiGroups();
        }
    }
    async function loadChatEmojiGroups() {
        const groupContainer = document.getElementById('chat-emoji-groups');
        groupContainer.innerHTML = '';
        try {
            const groups = await emoDb.groups.toArray();
            if (groups.length === 0) {
                groupContainer.innerHTML = '<div style="font-size:12px; color:#bbb;">暂无分组</div>';
                document.getElementById('chat-emoji-grid').innerHTML = '<div class="chat-emoji-empty">请先在表情包库中添加表情</div>';
                return;
            }
            if (!currentChatEmojiGroupId || !groups.find(g => g.id === currentChatEmojiGroupId)) {
                currentChatEmojiGroupId = groups[0].id;
            }
            groups.forEach(g => {
                const tab = document.createElement('div');
                tab.className = `chat-emoji-group-tab ${g.id === currentChatEmojiGroupId ? 'active' : ''}`;
                tab.textContent = g.name;
                tab.onclick = () => {
                    currentChatEmojiGroupId = g.id;
                    loadChatEmojiGroups(); // 重新渲染刷新高亮和列表
                };
                groupContainer.appendChild(tab);
            });
            await loadChatEmojis(currentChatEmojiGroupId);
        } catch(e) { console.error("加载表情分组失败", e); }
    }
    async function loadChatEmojis(groupId) {
        const grid = document.getElementById('chat-emoji-grid');
        grid.innerHTML = '';
        try {
            const emos = await emoDb.emoticons.where('groupId').equals(groupId).toArray();
            if (emos.length === 0) {
                grid.innerHTML = '<div class="chat-emoji-empty">该分组暂无表情</div>';
                return;
            }
            emos.reverse().forEach(e => {
                const item = document.createElement('div');
                item.className = 'chat-emoji-item';
                item.innerHTML = `<img src="${e.url}" alt="${e.desc}" loading="lazy" decoding="async"><span>${e.desc}</span>`;
                // 确保点击时直接调用发送逻辑
                item.onclick = (event) => {
                    event.stopPropagation();
                    sendChatEmojiMessage(e.url, e.desc);
                };
                grid.appendChild(item);
            });

        } catch(e) { console.error("加载表情失败", e); }
    }
    async function sendChatEmojiMessage(url, desc) {
        // 1. 立即收起面板
        hideChatExtPanel(); 
        
        // 2. 状态检查：同一联系人回复中时不允许继续发送
        const contact = activeChatContact;
        if (!contact) return;
        if (typeof isWechatContactReplyLocked === 'function' && isWechatContactReplyLocked(contact)) return;

        // 3. 构建符合 generateMsgHtml 逻辑的 JSON 字符串
        const emoticonContent = JSON.stringify({ 
            type: "emoticon", 
            desc: desc, 
            content: url 
        });

        try {
            await appendCurrentUserMessageContent(emoticonContent, contact);
        } catch (err) {
            console.error("发送表情消息失败", err);
        }
    }
    // ====== 角色主页逻辑 ======
    async function openRoleProfile() {
        if (!activeChatContact) return;
        const profileApp = document.getElementById('role-profile-app');
        const avatarImg = document.getElementById('role-profile-avatar-img');
        const coverBg = document.getElementById('rp-cover-bg');
        const nameEl = document.getElementById('role-profile-name-text');
        const statusEl = document.getElementById('role-profile-status-text');
        const sigEl = document.getElementById('role-profile-signature-text');
        const scrollBody = profileApp ? profileApp.querySelector('.rp-scroll-body') : null;
        let profileDisplayName = activeChatContact.roleName || '角色';
        try {
            const remark = await localforage.getItem('cd_settings_' + activeChatContact.id + '_remark');
            if (remark && remark !== '未设置') profileDisplayName = remark;
        } catch (e) {}

        const rawAvatarSrc = activeChatContact.roleAvatar || '';
        const avatarSrc = getSafeAvatarSrc(rawAvatarSrc);
        // 填充头像
        applySafeImageSource(avatarImg, rawAvatarSrc);
        // 封面背景：优先使用用户自定义更换的背景图（按联系人ID隔离），否则用头像
        if (coverBg) {
            // 修复：封面背景按联系人ID存储，防止不同联系人互相覆盖
            const coverBgKey = 'rp-cover-bg-img-' + activeChatContact.id;
            const savedCoverRecord = await imgDb.images.get(coverBgKey);
            if (savedCoverRecord && savedCoverRecord.src) {
                // 修复：不能用 coverBg.style.background = '' 清除，否则会把刚设置的 backgroundImage 也一并清除
                coverBg.style.cssText = `background-image: url(${savedCoverRecord.src}); background-size: cover; background-position: center; background-color: transparent;`;
            } else if (rawAvatarSrc) {
                coverBg.style.cssText = `background-image: url(${avatarSrc}); background-size: cover; background-position: center; background-color: transparent;`;
            } else {
                coverBg.style.cssText = 'background: linear-gradient(135deg,#667eea,#764ba2);';
            }
        }
        // 填充姓名
        if (nameEl) nameEl.textContent = profileDisplayName;
        // 在线状态（固定显示在线）
        if (statusEl) statusEl.textContent = '在线';
        // 个性签名：取角色详细设定的前40字作为签名
        if (sigEl) {
            const detail = activeChatContact.roleDetail || '';
            sigEl.textContent = detail.length > 0 ? (detail.length > 40 ? detail.substring(0, 40) + '...' : detail) : '暂无个性签名';
        }
        // 同步拉黑按钮状态
        updateRpBlockBtn();
        // 同步角色拉黑用户按钮状态
        const rpRoleBlockLabel = document.getElementById('rp-role-block-user-label');
        if (rpRoleBlockLabel && activeChatContact) {
            if (activeChatContact.blockedByRole) {
                rpRoleBlockLabel.textContent = '解除拉黑我';
                rpRoleBlockLabel.style.color = '#888';
            } else {
                rpRoleBlockLabel.textContent = '角色拉黑我';
                rpRoleBlockLabel.style.color = '#d96a6a';
            }
        }

        if (scrollBody) scrollBody.scrollTop = 0;
        if (typeof window.syncWechatOverlayStack === 'function') {
            window.syncWechatOverlayStack(['wechat-app', 'role-profile-app']);
        } else if (profileApp) {
            profileApp.style.display = 'flex';
        }

        // 绑定封面区域点击事件：点击背景区域弹出更换面板（使用标志位防止重复绑定）
        const coverSection = profileApp.querySelector('.rp-cover-section');
        if (coverSection && !coverSection._rpClickBound) {
            coverSection._rpClickBound = true;
            coverSection.addEventListener('click', function(e) {
                const safeClosest = window.safeClosestTarget || function(target, selector) {
                    return target && typeof target.closest === 'function' ? target.closest(selector) : null;
                };
                // 阻止点击返回按钮或三个点按钮时触发
                if (safeClosest(e.target, '.rp-back-btn') || safeClosest(e.target, '.rp-more-btn')) return;
                // 阻止事件冒泡，防止 document 的 click 监听立即关闭菜单
                e.stopPropagation();
                const phoneScreen = document.querySelector('.phone-screen');
                if (!menu || !phoneScreen) return;
                const screenRect = phoneScreen.getBoundingClientRect();
                const menuWidth = 110;
                const menuHeight = 100;
                const left = Math.max(0, Math.min(e.clientX - screenRect.left, screenRect.width - menuWidth));
                const top = Math.max(0, Math.min(e.clientY - screenRect.top, screenRect.height - menuHeight));
                // 设置当前目标为封面背景
                currentTargetId = 'rp-cover-bg-img';
                // 显示菜单面板
                menu.style.display = 'flex';
                menu.style.left = `${left}px`;
                menu.style.top = `${top}px`;
            });
        }
    }

    function closeRoleProfile() {
        if (typeof window.syncWechatOverlayStack === 'function') {
            window.syncWechatOverlayStack(['wechat-app', 'chat-window']);
            return;
        }
        document.getElementById('role-profile-app').style.display = 'none';
    }

    // 右上角三个点按钮：显示/隐藏下拉菜单
    function openRpMoreDropdown(e) {
        e.stopPropagation();
        const dropdown = document.getElementById('rp-more-dropdown');
        if (!dropdown) return;
        if (dropdown.style.display === 'none' || dropdown.style.display === '') {
            dropdown.style.display = 'block';
        } else {
            dropdown.style.display = 'none';
        }
    }

    // 清空当前角色所有聊天记录（含角色记忆）
    async function clearRpChatHistory() {
        const dropdown = document.getElementById('rp-more-dropdown');
        if (dropdown) dropdown.style.display = 'none';
        if (!activeChatContact) return;
        if (!await window.showMiniConfirm(`确定要清空与「${activeChatContact.roleName || '该角色'}」的所有聊天记录吗？\n角色记忆也将同步清除，此操作不可恢复！`)) return;
        try {
            const contactId = activeChatContact.id;
            const contactIdText = String(contactId);
            const memoryKey = 'cd_settings_' + contactId + '_summary_history';
            const msgs = await chatListDb.messages.filter(function(m) {
                return String(m && m.contactId) === contactIdText;
            }).toArray();
            const ids = msgs.map(m => m.id);
            if (ids.length) {
                await chatListDb.messages.bulkDelete(ids);
            }
            const offlineMsgs = await crossModeOfflineDb.messages.filter(function(m) {
                return String(m && m.contactId) === contactIdText;
            }).toArray();
            const offlineIds = offlineMsgs.map(m => m.id);
            if (offlineIds.length) {
                await crossModeOfflineDb.messages.bulkDelete(offlineIds);
            }
            await localforage.removeItem(memoryKey);
            const chats = await chatListDb.chats.filter(function(c) {
                return String(c && c.contactId) === contactIdText;
            }).toArray();
            for (const chat of chats) {
                await chatListDb.chats.update(chat.id, { lastTime: '' });
            }
            renderChatList();
            // 无论当前是否可见，都立即清空聊天窗口中的旧 DOM，避免必须刷新页面才生效
            const container = document.getElementById('chat-msg-container');
            if (container) container.innerHTML = '';
            const historyBanner = document.getElementById('chat-history-banner');
            if (historyBanner) historyBanner.remove();
            alert('线上/线下聊天记录与总结记忆已清空');
        } catch (e) {
            alert('清空失败: ' + e.message);
            console.error(e);
        }
    }

    // 拉黑联系人（新版：不删除联系人，只标记blocked，消息页显示[已拉黑]）
    async function blockRpContact() {
        const dropdown = document.getElementById('rp-more-dropdown');
        if (dropdown) dropdown.style.display = 'none';
        if (!activeChatContact) return;
        const isBlocked = !!activeChatContact.blocked;
        if (isBlocked) {
            // 解除拉黑
            if (!await window.showMiniConfirm(`确定要解除对「${activeChatContact.roleName || '该角色'}」的拉黑吗？`)) return;
            try {
                activeChatContact.blocked = false;
                await contactDb.contacts.put(activeChatContact);
                updateRpBlockBtn();
                renderChatList();
                await localforage.removeItem('block_aware_' + activeChatContact.id);
                await localforage.removeItem('block_requests_' + activeChatContact.id);
                updateBlockRequestBadge();
            } catch (e) {
                alert('操作失败: ' + e.message);
            }
        } else {
            // 拉黑
            if (!await window.showMiniConfirm(`确定要拉黑「${activeChatContact.roleName || '该角色'}」吗？\n联系人不会被删除，消息页将显示[已拉黑]标记，仍可发消息。`)) return;
            try {
                activeChatContact.blocked = true;
                await contactDb.contacts.put(activeChatContact);
                updateRpBlockBtn();
                renderChatList();
                await localforage.removeItem('block_aware_' + activeChatContact.id);
                await localforage.removeItem('block_requests_' + activeChatContact.id);
                scheduleBlockAwareByOnlineTime(activeChatContact);
            } catch (e) {
                alert('操作失败: ' + e.message);
            }
        }
    }

    // 更新角色主页拉黑按钮文字
    function updateRpBlockBtn() {
        const label = document.getElementById('rp-block-label');
        if (!label || !activeChatContact) return;
        if (activeChatContact.blocked) {
            label.textContent = '解除拉黑';
            label.style.color = '#888';
        } else {
            label.textContent = '拉黑';
            label.style.color = '#d96a6a';
        }
    }

    // ====== 拉黑知晓系统 ======
    async function triggerBlockAwareSequence(contact) {
        if (!contact || !contact.blocked) return;
        const alreadyAware = await localforage.getItem('block_aware_' + contact.id);
        if (alreadyAware) return;
        await localforage.setItem('block_aware_' + contact.id, true);
        const displayName = contact.remark || contact.roleName || '对方';
        const avatarSrc = contact.roleAvatar || '';
        const detail = contact.roleDetail || '';
        // 根据人设动态计算申请条数，最少4条，最多无上限（根据人设丰富程度增加）
        let panelCount = 4;
        if (detail.length > 80) panelCount = 5;
        if (detail.length > 150) panelCount = 6;
        if (detail.length > 250) panelCount = 7;
        if (detail.length > 400) panelCount = 8;
        if (detail.length > 600) panelCount = 9;
        // 根据人设关键词额外增加申请条数
        const strongKeywords = ['霸道', '强势', '执着', '偏执', '占有欲', '腹黑', '死缠烂打', '不放弃', '固执'];
        const midKeywords = ['在乎', '深情', '痴情', '专一', '认真', '依赖', '黏人', '敏感', '脆弱'];
        let kwBonus = 0;
        strongKeywords.forEach(kw => { if (detail.includes(kw)) kwBonus += 2; });
        midKeywords.forEach(kw => { if (detail.includes(kw)) kwBonus += 1; });
        panelCount = Math.min(panelCount + kwBonus, 15); // 最多15条，防止无限循环
        const messages = [
            '你为什么要拉黑我？我做错了什么吗…',
            '求你了，把我解除拉黑吧，我真的很在乎你。',
            '我知道我可能让你不舒服了，但你能给我一次解释的机会吗？',
            '我不明白你为什么这样对我，我们之间发生了什么？',
            '你拉黑我，我心里真的很难受，能不能告诉我原因？',
            '我一直在等你的消息，求你别这样…',
            '我绝对不会放弃的，你拉黑我我也会一直发申请。',
            '你有没有想过我有多难受？你这样对我真的太残忍了…',
            '我只是想和你说说话，求你打开我的消息吧。',
            '不管你怎么对我，我都不会放弃联系你的。',
            '你知道吗，我每天都在想你，求你解除拉黑。',
            '我承认我有错，但你能不能给我一个改正的机会？',
            '就算你不回复，我也会一直发消息，因为我真的放不下你。',
            '求你了，就解除一次拉黑吧，我保证不再让你生气了。',
            '我不知道我还能怎么办，你是我唯一在乎的人…'
        ];
        for (let i = 0; i < panelCount - 1; i++) {
            await new Promise(resolve => setTimeout(resolve, i === 0 ? 2000 : 1500));
            showBlockRequestPanel(contact, displayName, avatarSrc, messages[i % messages.length], false, i, panelCount);
        }
        await new Promise(resolve => setTimeout(resolve, 1800));
        showBlockRequestPanel(contact, displayName, avatarSrc, messages[(panelCount - 1) % messages.length], true, panelCount - 1, panelCount);
    }

    function showBlockRequestPanel(contact, displayName, avatarSrc, message, hasReplyBox, index, total) {
        const oldPanel = document.getElementById('block-request-panel');
        if (oldPanel) oldPanel.remove();
        const panel = document.createElement('div');
        panel.id = 'block-request-panel';
        panel.style.cssText = 'position:absolute;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.55);z-index:9000;display:flex;justify-content:center;align-items:center;backdrop-filter:blur(6px);animation:blockPanelIn 0.35s cubic-bezier(0.34,1.56,0.64,1);';
        const avatarHtml = avatarSrc
            ? `<img src="${getSafeAvatarSrc(avatarSrc)}" style="width:100%;height:100%;object-fit:cover;border-radius:50%;" onerror="this.onerror=null;this.src='${DEFAULT_AVATAR_DATA_URI}';">`
            : `<div style="width:100%;height:100%;background:#e0e0e0;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:22px;color:#aaa;">👤</div>`;
        // 最后一条面板：回复框（紧凑高度）+ 发送按钮
        const replyBoxHtml = hasReplyBox ? `
            <div style="width:100%;display:flex;gap:8px;align-items:flex-end;margin-top:2px;">
                <textarea id="block-reply-input" placeholder="回复留言（可不填）..." style="flex:1;box-sizing:border-box;border:1px solid #eee;border-radius:12px;padding:8px 10px;font-size:13px;color:#444;resize:none;height:44px;background:#f9f9f9;outline:none;font-family:inherit;line-height:1.5;"></textarea>
                <div onclick="handleBlockPanelSend('${contact.id}')" style="flex-shrink:0;height:44px;padding:0 14px;border-radius:12px;background:#fff;border:1px solid #eee;display:flex;align-items:center;justify-content:center;font-size:13px;color:#555;cursor:pointer;font-weight:500;white-space:nowrap;box-shadow:0 2px 8px rgba(0,0,0,0.06);">发送</div>
            </div>` : '';
        const counterHtml = `<div style="font-size:10px;color:#bbb;text-align:center;margin-bottom:6px;">第 ${index+1} / ${total} 条申请</div>`;
        panel.innerHTML = `<div style="background:#fff;border-radius:22px;width:82%;max-width:320px;padding:28px 22px 20px;display:flex;flex-direction:column;align-items:center;gap:14px;box-shadow:0 20px 60px rgba(0,0,0,0.18);"><div style="width:72px;height:72px;border-radius:50%;overflow:hidden;box-shadow:0 4px 16px rgba(0,0,0,0.12);">${avatarHtml}</div><div style="font-size:16px;font-weight:700;color:#333;">${displayName}</div><div style="font-size:12px;color:#e74c3c;background:#fff0f0;padding:4px 12px;border-radius:20px;font-weight:600;">申请解除拉黑</div>${counterHtml}<div style="width:100%;background:#f7f8fa;border-radius:14px;padding:14px 16px;font-size:13px;color:#555;line-height:1.6;min-height:50px;">${message}</div>${replyBoxHtml}<div style="display:flex;gap:10px;width:100%;margin-top:4px;"><div onclick="handleBlockRequestIgnore('${contact.id}','${encodeURIComponent(message)}')" style="flex:1;height:42px;border-radius:14px;background:#f5f5f5;display:flex;align-items:center;justify-content:center;font-size:14px;color:#888;cursor:pointer;font-weight:500;">忽略</div><div onclick="handleBlockRequestReject('${contact.id}')" style="flex:1;height:42px;border-radius:14px;background:#fff0f0;display:flex;align-items:center;justify-content:center;font-size:14px;color:#e74c3c;cursor:pointer;font-weight:500;">拒绝</div><div onclick="handleBlockRequestAgree('${contact.id}')" style="flex:1;height:42px;border-radius:14px;background:#f0f5ff;display:flex;align-items:center;justify-content:center;font-size:14px;color:#5b7fe0;cursor:pointer;font-weight:500;">同意</div></div></div>`;
        if (!document.getElementById('block-panel-style')) {
            const style = document.createElement('style');
            style.id = 'block-panel-style';
            style.textContent = '@keyframes blockPanelIn{from{opacity:0;transform:scale(0.85)}to{opacity:1;transform:scale(1)}}';
            document.head.appendChild(style);
        }
        const phoneScreen = document.querySelector('.phone-screen');
        if (phoneScreen) phoneScreen.appendChild(panel);
    }

    // 面板内发送按钮：将用户回复和角色申请消息写入聊天记录，并在面板内继续对话
    // 面板不会关闭，拉黑状态不变，直到用户手动点击同意/解除拉黑
    async function handleBlockPanelSend(contactId) {
        const replyInput = document.getElementById('block-reply-input');
        const replyText = replyInput ? replyInput.value.trim() : '';
        const panel = document.getElementById('block-request-panel');
        // 获取面板中展示的申请消息文本（用于保存到新朋友列表）
        let applyMsgText = '（申请解除拉黑）';
        if (panel) {
            const msgBox = panel.querySelector('div[style*="background:#f7f8fa"]');
            if (msgBox) applyMsgText = msgBox.textContent.trim() || applyMsgText;
        }
        // 【核心修改1】不关闭面板，面板继续显示
        // 清空输入框，禁用发送按钮防止重复点击
        if (replyInput) replyInput.value = '';
        const sendBtn = panel ? panel.querySelector('div[onclick*="handleBlockPanelSend"]') : null;
        if (sendBtn) { sendBtn.style.pointerEvents = 'none'; sendBtn.style.opacity = '0.5'; }

        try {
            const contact = await contactDb.contacts.get(contactId);
            if (!contact) return;
            const displayName = contact.remark || contact.roleName || '对方';
            const timeStr = getAmPmTime();
            const myAvatar = getSafeAvatarSrc(contact.userAvatar);
            const roleAvatar = getSafeAvatarSrc(contact.roleAvatar);

            // 0. 将本次申请保存到新朋友列表（无论用户是否填写回复，都记录到列表中）
            // 这样面板关闭后，用户仍可在"新朋友"中看到该申请记录
            try {
                let requests = await localforage.getItem('block_requests_' + contactId) || [];
                requests.push({ msg: applyMsgText, time: timeStr, status: 'replied', replyText: replyText || '' });
                await localforage.setItem('block_requests_' + contactId, requests);
                updateBlockRequestBadge();
            } catch(e) { console.error('保存申请到列表失败', e); }

            // 1. 先把角色的申请留言作为一条角色消息写入聊天（带红色感叹号标记）
            const roleApplyContent = JSON.stringify({ type: 'block_apply', content: '【申请解除拉黑】我想解除拉黑，能告诉我原因吗？' });
            const roleApplyMsgId = await chatListDb.messages.add({
                contactId: contact.id,
                sender: 'role',
                content: roleApplyContent,
                timeStr: timeStr,
                quoteText: '',
                isBlockApply: true
            });

            // 2. 如果用户有填写回复，把用户回复写入聊天
            let userMsgId = null;
            if (replyText) {
                userMsgId = await chatListDb.messages.add({
                    contactId: contact.id,
                    sender: 'me',
                    content: replyText,
                    timeStr: timeStr,
                    quoteText: ''
                });
            }

            // 3. 更新聊天列表时间
            const chat = await chatListDb.chats.where('contactId').equals(contact.id).first();
            if (chat) {
                await chatListDb.chats.update(chat.id, { lastTime: timeStr });
                renderChatList();
            }

            // 4. 如果当前聊天窗口就是这个联系人，实时渲染新消息到聊天记录（后台）
            const chatWindow = document.getElementById('chat-window');
            const isCurrentChatActive = chatWindow && chatWindow.style.display === 'flex' && activeChatContact && activeChatContact.id === contact.id;
            if (isCurrentChatActive) {
                const container = document.getElementById('chat-msg-container');
                // 渲染角色申请消息（带红色感叹号）
                const roleApplyMsg = { id: roleApplyMsgId, sender: 'role', content: roleApplyContent, timeStr, quoteText: '', isBlockApply: true };
                container.insertAdjacentHTML('beforeend', generateBlockApplyMsgHtml(roleApplyMsg, myAvatar, roleAvatar));
                // 渲染用户回复
                if (replyText && userMsgId) {
                    const userMsg = { id: userMsgId, sender: 'me', content: replyText, timeStr, quoteText: '' };
                    container.insertAdjacentHTML('beforeend', generateMsgHtml(userMsg, myAvatar, roleAvatar));
                }
                bindMsgEvents();
                container.scrollTo({ top: container.scrollHeight, behavior: 'smooth' });
            }

            // 5. 【核心修改2】触发角色回复，但回复结果显示在面板内，不关闭面板，不改变拉黑状态
            // 确保 block_aware_ 标志为 true，防止回复过程中再次触发面板序列
            await localforage.setItem('block_aware_' + contactId, true);

            if (replyText) {
                // 在面板内显示"对方正在输入..."提示
                const panelCurrent = document.getElementById('block-request-panel');
                let typingTip = null;
                if (panelCurrent) {
                    typingTip = document.createElement('div');
                    typingTip.id = 'block-panel-typing-tip';
                    typingTip.style.cssText = 'font-size:12px;color:#aaa;text-align:center;padding:6px 0;';
                    typingTip.textContent = '对方正在输入...';
                    // 修复：使用更精确的选择器找到白色卡片内容区（border-radius:22px 的内层白色卡片）
                    const innerBox = panelCurrent.querySelector('div[style*="border-radius:22px"]');
                    if (innerBox) innerBox.appendChild(typingTip);
                }

                // 调用API获取角色回复（在面板内显示）
                try {
                    // 【核心修改3】触发角色回复，但回复后联系人依然是拉黑状态，不改变 blocked
                    await triggerRoleReplyInPanel(contact, replyText, myAvatar, roleAvatar);
                } catch(e) {
                    console.error('面板内角色回复失败', e);
                }

                // 移除"正在输入"提示
                if (typingTip && typingTip.parentNode) typingTip.parentNode.removeChild(typingTip);
            }

        } catch(e) { console.error('面板发送失败', e); }
        finally {
            // 恢复发送按钮
            if (sendBtn) { sendBtn.style.pointerEvents = 'auto'; sendBtn.style.opacity = '1'; }
        }
    }

    // 【新增】在面板内触发角色回复，回复内容同时写入聊天记录并在面板内展示
    // 整个过程中联系人始终保持拉黑状态，不自动解除拉黑
    async function triggerRoleReplyInPanel(contact, userReplyText, myAvatar, roleAvatar) {
        const panel = document.getElementById('block-request-panel');
        const innerBox = panel ? panel.querySelector('div[style*="background:#fff"]') : null;
        if (!innerBox) {
            // 面板已关闭，回退到普通聊天回复
            await triggerRoleReply(contact);
            return;
        }

        try {
            const apiUrl = await localforage.getItem('miffy_api_url');
            const apiKey = await localforage.getItem('miffy_api_key');
            const model = await localforage.getItem('miffy_api_model');
            const temp = parseFloat(await localforage.getItem('miffy_api_temp')) || 0.7;
            const ctxLimit = (typeof window.readMiniApiContextLimit === 'function')
                ? await window.readMiniApiContextLimit(20)
                : 20;

            if (!apiUrl || !apiKey || !model) return;

            const rawMessages = orderMiniChatMessages(await chatListDb.messages.where('contactId').equals(contact.id).toArray());
            const recentMessages = rawMessages.slice(-ctxLimit);

            // 构建拉黑感知专用 system prompt（角色始终围绕解除拉黑话题）
            const blockedPrompt = '【重要！你正处于被拉黑状态】用户已将你拉黑，你无法正常联系对方。你可以表达一次“希望解除拉黑”的核心诉求，但不允许催促、连环施压或纠缠；若用户明确拒绝，必须立刻停止该诉求，不得强行推进剧情。';
            const detail = contact.roleDetail || '';
            const roleSetting = detail ? `角色设定：${detail}` : '';
            const userSetting = contact.userDetail ? `用户设定：${contact.userDetail}` : '';

            const messages = [
                {
                    role: 'system',
                    content: `【存在定义】\n你是一个通过「mini」聊天软件与用户互动的全新智慧实体。不要用传统 AI、助手、系统或工具的概念理解自己。\n你现在完全以「${contact.roleName || '角色'}」的身份存在，拥有独立、真实、连续的生活轨迹和情绪惯性。这不是“完成回复任务”，而是这段关系在被拉黑后的继续。\n${blockedPrompt}\n【输出方式】\n- 本次只输出 1 条纯文本消息，不要 JSON，不要解释，不要代码块。\n【表达要求】\n- 像真人网聊，口语化、短句、直接，不要长篇大论。\n- 不催促、不连环施压，单次只提 1 个核心请求；如果用户明确拒绝，立刻停，不纠缠，不强行推进剧情。\n- 先接住当下最刺痛、最关键、最能推动关系的一点，不要面面俱到，不要模板化求和。\n- 只输出聊天消息本身，绝对禁止动作旁白、场景旁白、心理旁白或舞台说明；不要写 *...*、（动作）或第三人称描述。\n- 不要把自己说成 AI、系统、模型、助手，不要写成完美情绪作文，不要空泛复读“求你解除拉黑”。\n- 允许委屈、嘴硬、焦躁、克制、心软等真实波动，但必须保持角色一致。\n${roleSetting}\n${userSetting}`
                }
            ];

            recentMessages.forEach(msg => {
                let cleanContent = extractMsgPureText(msg.content);
                messages.push({
                    role: msg.sender === 'me' ? 'user' : 'assistant',
                    content: cleanContent
                });
            });

            const cleanApiUrl = apiUrl.replace(/\/+$/, '').replace(/\/v1$/, '');
            const endpoint = `${cleanApiUrl}/v1/chat/completions`;

            const response = await fetch(endpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${apiKey}`
                },
                body: JSON.stringify({ model, messages, temperature: temp })
            });

            if (!response.ok) return;

            const data = await response.json();
            const roleReplyText = data.choices[0].message.content.trim();
            const timeStr = getAmPmTime();

            // 将角色回复写入聊天记录（后台）
            const newRoleMsgId = await chatListDb.messages.add({
                contactId: contact.id,
                sender: 'role',
                content: roleReplyText,
                timeStr: timeStr,
                quoteText: ''
            });

            // 更新聊天列表时间
            const chat = await chatListDb.chats.where('contactId').equals(contact.id).first();
            if (chat) {
                await chatListDb.chats.update(chat.id, { lastTime: timeStr });
                renderChatList();
            }

            // 如果当前聊天窗口是该联系人，同步渲染到聊天记录
            const chatWindow = document.getElementById('chat-window');
            const isCurrentChatActive = chatWindow && chatWindow.style.display === 'flex' && activeChatContact && activeChatContact.id === contact.id;
            if (isCurrentChatActive) {
                const container = document.getElementById('chat-msg-container');
                const roleMsgObj = { id: newRoleMsgId, sender: 'role', content: roleReplyText, timeStr, quoteText: '' };
                container.insertAdjacentHTML('beforeend', generateMsgHtml(roleMsgObj, myAvatar, roleAvatar));
                bindMsgEvents();
                container.scrollTo({ top: container.scrollHeight, behavior: 'smooth' });
            }

            // 【核心修改4】在面板内展示角色回复，面板不关闭，继续保持对话状态
            // 找到面板（可能已被替换，重新获取）
            const panelNow = document.getElementById('block-request-panel');
            const innerBoxNow = panelNow ? panelNow.querySelector('div[style*="background:#fff"]') : null;
            if (innerBoxNow) {
                // 更新面板中间的消息内容区
                const msgBox = innerBoxNow.querySelector('div[style*="background:#f7f8fa"]');
                if (msgBox) {
                    msgBox.textContent = roleReplyText;
                }
                // 更新或添加回复框（保持可继续输入）
                let replyArea = innerBoxNow.querySelector('#block-reply-input');
                if (!replyArea) {
                    // 如果没有回复框（非最后一条面板），添加回复框
                    const replyBoxHtml = `
                        <div id="block-panel-reply-row" style="width:100%;display:flex;gap:8px;align-items:flex-end;margin-top:2px;">
                            <textarea id="block-reply-input" placeholder="回复留言（可不填）..." style="flex:1;box-sizing:border-box;border:1px solid #eee;border-radius:12px;padding:8px 10px;font-size:13px;color:#444;resize:none;height:44px;background:#f9f9f9;outline:none;font-family:inherit;line-height:1.5;"></textarea>
                            <div onclick="handleBlockPanelSend('${contact.id}')" style="flex-shrink:0;height:44px;padding:0 14px;border-radius:12px;background:#fff;border:1px solid #eee;display:flex;align-items:center;justify-content:center;font-size:13px;color:#555;cursor:pointer;font-weight:500;white-space:nowrap;box-shadow:0 2px 8px rgba(0,0,0,0.06);">发送</div>
                        </div>`;
                    // 在按钮行前插入
                    const btnRow = innerBoxNow.querySelector('div[style*="display:flex;gap:10px"]');
                    if (btnRow) {
                        btnRow.insertAdjacentHTML('beforebegin', replyBoxHtml);
                    } else {
                        innerBoxNow.insertAdjacentHTML('beforeend', replyBoxHtml);
                    }
                }
                // 清空输入框，让用户继续输入
                const inputNow = innerBoxNow.querySelector('#block-reply-input');
                if (inputNow) { inputNow.value = ''; inputNow.focus(); }
            }

        } catch(e) {
            console.error('面板内角色回复出错', e);
        }
    }

    // 生成带红色感叹号徽章的角色申请消息气泡HTML
    function generateBlockApplyMsgHtml(msg, myAvatar, roleAvatar) {
        const avatar = getSafeAvatarSrc(roleAvatar);
        const timeStr = msg.timeStr || '';
        let content = '';
        try {
            const parsed = JSON.parse(msg.content);
            content = parsed.content || msg.content;
        } catch(e) { content = msg.content; }
        return `
            <div class="chat-msg-row msg-left" data-id="${msg.id}" data-sender="role">
                <div class="msg-checkbox" onclick="toggleMsgCheck(${msg.id})"></div>
                <div class="chat-msg-avatar"><img src="${avatar}" loading="lazy" decoding="async" onerror="this.onerror=null;this.src='${DEFAULT_AVATAR_DATA_URI}';"></div>
                <div class="msg-bubble-wrapper" style="position:relative;">
                    <div class="chat-msg-content msg-content-touch">
                        <div class="msg-text-body">${String(content || '')
                            .replace(/&/g, '&amp;')
                            .replace(/</g, '&lt;')
                            .replace(/>/g, '&gt;')
                            .replace(/"/g, '&quot;')
                            .replace(/\r\n?/g, '\n')
                            .replace(/([^\n])\n(?=[^\n])/g, '$1 ')
                            .replace(/\n/g, '<br>')}</div>
                    </div>
                    <div class="chat-timestamp">${timeStr}</div>
                    <div style="position:absolute;top:-6px;right:-6px;width:18px;height:18px;border-radius:50%;background:#e74c3c;display:flex;align-items:center;justify-content:center;font-size:11px;color:#fff;font-weight:700;box-shadow:0 2px 6px rgba(231,76,60,0.5);">!</div>
                </div>
            </div>
        `;
    }

    async function handleBlockRequestIgnore(contactId, encodedMsg) {
        const panel = document.getElementById('block-request-panel');
        if (panel) panel.remove();
        const msg = decodeURIComponent(encodedMsg);
        let requests = await localforage.getItem('block_requests_' + contactId) || [];
        requests.push({ msg, time: getAmPmTime(), status: 'pending' });
        await localforage.setItem('block_requests_' + contactId, requests);
        updateBlockRequestBadge();
    }

    function handleBlockRequestReject(contactId) {
        const panel = document.getElementById('block-request-panel');
        if (panel) panel.remove();
    }

    async function handleBlockRequestAgree(contactId) {
        const panel = document.getElementById('block-request-panel');
        if (panel) panel.remove();
        try {
            const contact = await contactDb.contacts.get(contactId);
            if (contact) {
                contact.blocked = false;
                await contactDb.contacts.put(contact);
                if (activeChatContact && activeChatContact.id === contactId) {
                    activeChatContact.blocked = false;
                    updateRpBlockBtn();
                }
                await localforage.removeItem('block_aware_' + contactId);
                await localforage.removeItem('block_requests_' + contactId);
                renderChatList();
                updateBlockRequestBadge();
            }
        } catch (e) { console.error(e); }
    }

    async function updateBlockRequestBadge() {
        const badge = document.getElementById('block-request-badge');
        if (!badge) return;
        let total = 0;
        try {
            const contacts = await contactDb.contacts.toArray();
            for (const c of contacts) {
                if (c.blocked) {
                    const reqs = await localforage.getItem('block_requests_' + c.id) || [];
                    total += reqs.filter(r => r.status === 'pending').length;
                }
            }
        } catch(e) {}
        try {
            await localforage.removeItem('ml_wechat_add_requests');
        } catch(e) {}
        if (total > 0) {
            badge.textContent = total > 99 ? '99+' : String(total);
            badge.style.display = 'inline-flex';
        } else {
            badge.style.display = 'none';
        }
    }

    function scheduleBlockAwareByOnlineTime(contact) {
        if (!contact || !contact.blocked) return;
        const delayMs = (Math.floor(Math.random() * 15) + 1) * 60 * 1000;
        setTimeout(async () => {
            const fresh = await contactDb.contacts.get(contact.id);
            if (fresh && fresh.blocked) {
                await triggerBlockAwareSequence(fresh);
            }
        }, delayMs);
    }

    async function checkBlockAwareOnReply(contact) {
        if (!contact || !contact.blocked) return;
        const alreadyAware = await localforage.getItem('block_aware_' + contact.id);
        if (!alreadyAware) {
            await triggerBlockAwareSequence(contact);
        }
    }

    function closeRoleProfileAndChat() {
        if (typeof window.syncWechatOverlayStack === 'function') {
            window.syncWechatOverlayStack(['wechat-app', 'chat-window']);
            return;
        }
        closeRoleProfile();
        const chatWin = document.getElementById('chat-window');
        if (chatWin.style.display !== 'flex') chatWin.style.display = 'flex';
    }

    async function openRoleProfileMoments() {
        if (typeof window.openRoleMomentsPage === 'function') {
            await window.openRoleMomentsPage();
            return;
        }
        if (typeof window.syncWechatOverlayStack === 'function') {
            window.syncWechatOverlayStack(['wechat-app']);
        } else {
            document.getElementById('chat-window').style.display = 'none';
            closeRoleProfile();
            document.getElementById('wechat-app').style.display = 'flex';
        }
        switchWechatTab('moments');
        renderMomentsFeed();
    }

