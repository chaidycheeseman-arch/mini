﻿// Auto-split from js/home/home-and-novel.js (4222-4525)

    // ====== 数据管理功能逻辑 ======
    // 图像压缩辅助函数 (使用 Canvas 降低图片分辨率和质量)
    function compressImageBase64(base64Str, maxWidth = 800, quality = 0.6) {
        return new Promise((resolve) => {
            if (!base64Str || !base64Str.startsWith('data:image')) {
                resolve(base64Str);
                return;
            }
            const img = new Image();
            img.onload = () => {
                let width = img.width;
                let height = img.height;
                if (width > maxWidth) {
                    height = Math.round((height * maxWidth) / width);
                    width = maxWidth;
                }
                const canvas = document.createElement('canvas');
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, width, height);
                
                // 判断原图格式，如果是 png 或 gif，则输出 png 以保留透明背景
                const isTransparent = base64Str.startsWith('data:image/png') || base64Str.startsWith('data:image/gif');
                const outType = isTransparent ? 'image/png' : 'image/jpeg';
                // 注意：png 格式忽略 quality 参数，但能保证不黑底
                resolve(canvas.toDataURL(outType, isTransparent ? undefined : quality));
            };
            img.onerror = () => resolve(base64Str);
            img.src = base64Str;

        });
    }
    // 压缩数据库中的所有图片数据
    async function compressData() {
        const btn = document.getElementById('btn-compress-data');
        if (!await window.showMiniConfirm('此操作将对数据库中的所有图片（头像、背景、聊天图片等）进行画质压缩，以大幅减小文件体积防止导出卡死。压缩后画质会有所降低，确定要继续吗？')) return;
        const originalText = btn.innerText;
        btn.innerText = "正在压缩，请勿进行其他操作...";
        btn.style.pointerEvents = "none";
        btn.style.opacity = "0.7";
        await new Promise(r => setTimeout(r, 100)); // 让UI更新
        try {
            // 1. 压缩 imgDb
            const images = await imgDb.images.toArray();
            for (let img of images) {
                if (img.src && img.src.startsWith('data:image')) {
                    img.src = await compressImageBase64(img.src);
                    await imgDb.images.put(img);
                }
            }
            // 2. 压缩 联系人头像
            const contacts = await contactDb.contacts.toArray();
            for (let c of contacts) {
                let updated = false;
                if (c.roleAvatar && c.roleAvatar.startsWith('data:image')) {
                    c.roleAvatar = await compressImageBase64(c.roleAvatar);
                    updated = true;
                }
                if (c.userAvatar && c.userAvatar.startsWith('data:image')) {
                    c.userAvatar = await compressImageBase64(c.userAvatar);
                    updated = true;
                }
                if (updated) await contactDb.contacts.put(c);
            }
            // 3. 压缩 面具预设头像
            const masks = await maskDb.presets.toArray();
            for (let m of masks) {
                if (m.avatar && m.avatar.startsWith('data:image')) {
                    m.avatar = await compressImageBase64(m.avatar);
                    await maskDb.presets.put(m);
                }
            }
            // 4. 压缩 聊天记录中的图片
            const msgs = await chatListDb.messages.toArray();
            for (let msg of msgs) {
                try {
                    const parsed = JSON.parse(msg.content);
                    if (parsed && parsed.type === 'image' && parsed.content && parsed.content.startsWith('data:image')) {
                        parsed.content = await compressImageBase64(parsed.content);
                        msg.content = JSON.stringify(parsed);
                        await chatListDb.messages.put(msg);
                    }
                } catch(e) {}
            }
            alert('图片数据压缩完成！现在可以尝试进行导出。');
        } catch (e) {
            console.error("压缩失败:", e);
            alert('压缩过程中出现错误: ' + e.message);
        } finally {
            btn.innerText = originalText;
            btn.style.pointerEvents = "auto";
            btn.style.opacity = "1";
        }
    }
    function getExportFileName() {
        const now = new Date();
        const y = now.getFullYear();
        const m = String(now.getMonth() + 1).padStart(2, '0');
        const d = String(now.getDate()).padStart(2, '0');
        const h = String(now.getHours()).padStart(2, '0');
        const min = String(now.getMinutes()).padStart(2, '0');
        return `mini-${y}-${m}-${d}_${h}-${min}.json`;
    }
    const EXPORT_SCHEMA_VERSION = 2;
    const EXPORTABLE_DATA_KEYS = Object.freeze([
        'settings',
        'theme',
        'voice',
        'worldbook',
        'contacts',
        'wallet',
        'music',
        'masks',
        'emoticons',
        'images'
    ]);
    const EXPORTABLE_DATA_KEY_SET = new Set(EXPORTABLE_DATA_KEYS);
    const IMPORT_MODE_COMPATIBLE = 'compatible';
    const IMPORT_MODE_OVERWRITE = 'overwrite';
    const miniOfflineExportDb = new Dexie('miniPhoneOfflineDB');
    miniOfflineExportDb.version(1).stores({ messages: '++id, contactId, sender, content, timestamp' });
    const miniMemoryExportDb = new Dexie('miniPhoneMemoryCenterDB');
    miniMemoryExportDb.version(1).stores({
        notes: '++id, contactId, createdAt, updatedAt',
        schedules: '++id, contactId, dateKey, startTime, updatedAt'
    });
    let pendingImportPayload = null;
    let pendingImportInput = null;
    let pendingImportFileName = '';
    let pendingImportManifest = null;
    function normalizeSelectedExportKeys(selectedKeys) {
        return Array.from(new Set((Array.isArray(selectedKeys) ? selectedKeys : []).filter(key => EXPORTABLE_DATA_KEY_SET.has(key))));
    }
    function getLocalforageCategoriesForKey(key) {
        if (!key) return [];
        const categories = [];
        if (
            key.startsWith('miffy_api_') ||
            key === 'miffy_webpush_enabled' ||
            key.startsWith('miffy_device_lock_') ||
            key.startsWith('miffy_lite_device_lock_')
        ) {
            categories.push('settings');
        }
        if (
            key.startsWith('miffy_text_') ||
            key.startsWith('miffy_global_') ||
            key === 'miffy_ui_scale' ||
            key === 'miffy_theme_mode' ||
            key === 'miffy_custom_theme' ||
            key === 'miffy_custom_theme_presets' ||
            key === 'mini_wechat_chat_beautify_v1'
        ) {
            categories.push('theme');
        }
        if (
            key === 'miffy_contact_groups' ||
            key.startsWith('cd_settings_') ||
            key.startsWith('block_requests_') ||
            key.startsWith('block_aware_') ||
            key.startsWith('chat_timeline_state_') ||
            key.startsWith('chat_timeline_slot_') ||
            key.startsWith('offline_settings_') ||
            key === 'memory_center_selected_contact_id' ||
            key === 'miffy_moments_posts_v1' ||
            key === 'wechat_favorite_messages_v1' ||
            key.startsWith('mini_wechat_chat_beautify_role_v1:') ||
            key.startsWith('cp_sig_') ||
            key.startsWith('cp_wallpaper_') ||
            key.startsWith('cp_desktop_wallpaper_') ||
            key.startsWith('cp_profile_bg_') ||
            key.startsWith('cp_desktop_icon_')
        ) {
            categories.push('contacts');
        }
        if (key.startsWith('miffy_minimax_')) {
            categories.push('voice');
        }
        if (key === 'pay_password' || key === 'no_pwd_pay_enabled') {
            categories.push('wallet');
        }
        if (key === 'music_app_state_v1') {
            categories.push('music');
        }
        return categories;
    }
    function shouldExportLocalforageKey(selectedKeys, key) {
        const selectedSet = new Set(normalizeSelectedExportKeys(selectedKeys));
        return getLocalforageCategoriesForKey(key).some(category => selectedSet.has(category));
    }
    function getExportDbCatalog() {
        return [
            { key: 'db', categories: ['worldbook'], instance: db, stores: ['entries'] },
            { key: 'contactDb', categories: ['contacts'], instance: contactDb, stores: ['contacts'] },
            { key: 'chatListDb', categories: ['contacts'], instance: chatListDb, stores: ['chats', 'messages'] },
            { key: 'offlineDb', categories: ['contacts'], instance: miniOfflineExportDb, stores: ['messages'] },
            { key: 'memoryDb', categories: ['contacts'], instance: miniMemoryExportDb, stores: ['notes', 'schedules'] },
            { key: 'maskDb', categories: ['masks'], instance: maskDb, stores: ['presets'] },
            { key: 'emoDb', categories: ['emoticons'], instance: emoDb, stores: ['groups', 'emoticons'] },
            { key: 'imgDb', categories: ['images'], instance: imgDb, stores: ['images'] },
            { key: 'walletDb', categories: ['wallet'], instance: walletDb, stores: ['kv', 'bankCards', 'bills'] }
        ];
    }
    function getExportPlanForKeys(selectedKeys) {
        const selectedSet = new Set(normalizeSelectedExportKeys(selectedKeys));
        return getExportDbCatalog().filter(item => item.categories.some(category => selectedSet.has(category)));
    }
    function inferSelectedKeysFromPayload(data) {
        const inferred = new Set();
        if (!data || typeof data !== 'object') return [];
        const localforageData = data.localforage && typeof data.localforage === 'object' ? data.localforage : null;
        if (localforageData) {
            Object.keys(localforageData).forEach(key => {
                getLocalforageCategoriesForKey(key).forEach(category => inferred.add(category));
            });
        }
        if (data.db) inferred.add('worldbook');
        if (data.contactDb || data.chatListDb || data.offlineDb || data.memoryDb) inferred.add('contacts');
        if (data.maskDb) inferred.add('masks');
        if (data.emoDb) inferred.add('emoticons');
        if (data.imgDb) inferred.add('images');
        if (data.walletDb) inferred.add('wallet');
        return normalizeSelectedExportKeys(Array.from(inferred));
    }
    function buildImportManifest(data) {
        const meta = data && data.meta && typeof data.meta === 'object' ? data.meta : null;
        const selectedFromMeta = meta && Array.isArray(meta.selectedKeys) ? normalizeSelectedExportKeys(meta.selectedKeys) : [];
        return {
            schemaVersion: meta && Number.isFinite(Number(meta.schemaVersion)) ? Number(meta.schemaVersion) : 1,
            selectedKeys: selectedFromMeta.length ? selectedFromMeta : inferSelectedKeysFromPayload(data),
            isCompleteSelection: !!(meta && Number(meta.schemaVersion) >= EXPORT_SCHEMA_VERSION && selectedFromMeta.length)
        };
    }
    function isIosLikeDevice() {
        const nav = window.navigator || {};
        const ua = String(nav.userAgent || '');
        return /iPad|iPhone|iPod/i.test(ua) || (nav.platform === 'MacIntel' && nav.maxTouchPoints > 1);
    }
    async function downloadExportBlob(blob, fileName) {
        const nav = window.navigator || {};
        if (typeof nav.msSaveOrOpenBlob === 'function') {
            nav.msSaveOrOpenBlob(blob, fileName);
            return true;
        }
        if (typeof nav.msSaveBlob === 'function') {
            nav.msSaveBlob(blob, fileName);
            return true;
        }
        if (typeof nav.share === 'function' && typeof File === 'function') {
            try {
                const shareFile = new File([blob], fileName, { type: blob.type || 'application/json;charset=utf-8' });
                if (!nav.canShare || nav.canShare({ files: [shareFile] })) {
                    await nav.share({ files: [shareFile], title: fileName });
                    return true;
                }
            } catch (shareError) {
                if (shareError && shareError.name === 'AbortError') return false;
            }
        }
        const url = URL.createObjectURL(blob);
        let anchor = null;
        try {
            anchor = document.createElement('a');
            anchor.href = url;
            anchor.download = fileName;
            anchor.rel = 'noopener';
            anchor.target = '_blank';
            document.body.appendChild(anchor);
            anchor.click();
            if (isIosLikeDevice()) {
                setTimeout(() => {
                    if (document.visibilityState === 'visible') {
                        window.open(url, '_blank', 'noopener');
                    }
                }, 180);
            }
            return true;
        } finally {
            setTimeout(() => {
                if (anchor && document.body.contains(anchor)) document.body.removeChild(anchor);
                URL.revokeObjectURL(url);
            }, 10000);
        }
    }
    async function readImportFileText(file) {
        if (!file) return '';
        if (typeof file.text === 'function') {
            return await file.text();
        }
        return await new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => resolve(e && e.target ? String(e.target.result || '') : '');
            reader.onerror = reject;
            reader.readAsText(file, 'utf-8');
        });
    }
    function stableCloneForFingerprint(value) {
        if (Array.isArray(value)) {
            return value.map(stableCloneForFingerprint);
        }
        if (value && typeof value === 'object') {
            const result = {};
            Object.keys(value).sort().forEach(key => {
                result[key] = stableCloneForFingerprint(value[key]);
            });
            return result;
        }
        return value;
    }
    function removePrimaryKeyFromRecord(record, keyPath) {
        if (!record || !keyPath) return record;
        if (Array.isArray(keyPath)) {
            keyPath.forEach(key => {
                if (key) delete record[key];
            });
            return record;
        }
        if (typeof keyPath === 'string' && keyPath) {
            delete record[keyPath];
        }
        return record;
    }
    function buildStoreFingerprint(record, keyPath) {
        if (!record || typeof record !== 'object') return JSON.stringify(record);
        const cloned = stableCloneForFingerprint(record);
        removePrimaryKeyFromRecord(cloned, keyPath);
        return JSON.stringify(cloned);
    }
    async function runDexieBulk(table, method, items, chunkSize = 200) {
        if (!Array.isArray(items) || items.length === 0) return;
        for (let i = 0; i < items.length; i += chunkSize) {
            const chunk = items.slice(i, i + chunkSize);
            await table[method](chunk);
        }
    }
    async function restoreDexieStore(table, records, mode) {
        const nextRecords = Array.isArray(records) ? records : [];
        if (mode === IMPORT_MODE_OVERWRITE) {
            await table.clear();
            if (!nextRecords.length) return;
            await runDexieBulk(table, 'bulkPut', nextRecords);
            return;
        }
        const primaryKey = table.schema && table.schema.primKey ? table.schema.primKey : null;
        if (!primaryKey || !primaryKey.auto) {
            if (nextRecords.length) {
                await runDexieBulk(table, 'bulkPut', nextRecords);
            }
            return;
        }
        const existingRows = await table.toArray();
        const existingFingerprints = new Set(existingRows.map(row => buildStoreFingerprint(row, primaryKey.keyPath)));
        const toAdd = [];
        nextRecords.forEach(record => {
            const fingerprint = buildStoreFingerprint(record, primaryKey.keyPath);
            if (existingFingerprints.has(fingerprint)) return;
            existingFingerprints.add(fingerprint);
            const sanitized = JSON.parse(JSON.stringify(record));
            removePrimaryKeyFromRecord(sanitized, primaryKey.keyPath);
            toAdd.push(sanitized);
        });
        if (toAdd.length) {
            await runDexieBulk(table, 'bulkAdd', toAdd);
        }
    }
    async function clearLocalforageKeysByCategories(selectedKeys) {
        const selectedSet = new Set(normalizeSelectedExportKeys(selectedKeys));
        if (!selectedSet.size) return;
        const keys = await localforage.keys();
        for (const key of keys) {
            const categories = getLocalforageCategoriesForKey(key);
            if (categories.some(category => selectedSet.has(category))) {
                await localforage.removeItem(key);
            }
        }
    }
    async function clearDexieByCategories(selectedKeys) {
        const selectedSet = new Set(normalizeSelectedExportKeys(selectedKeys));
        const exportPlan = getExportDbCatalog().filter(item => item.categories.some(category => selectedSet.has(category)));
        for (const item of exportPlan) {
            for (const storeName of item.stores) {
                await item.instance[storeName].clear();
            }
        }
    }
    function updateImportModeDescription(fileName, manifest) {
        const nameEl = document.getElementById('import-mode-file-name');
        const descEl = document.getElementById('import-mode-desc');
        if (nameEl) {
            nameEl.textContent = fileName || '未命名备份';
        }
        if (descEl) {
            const categoryText = manifest && Array.isArray(manifest.selectedKeys) && manifest.selectedKeys.length
                ? `包含：${manifest.selectedKeys.join('、')}`
                : '将导入文件里检测到的数据';
            descEl.textContent = `${categoryText}。兼容会保留现有数据，覆盖会用备份替换同类数据。`;
        }
    }
    function openImportModeModal(fileName, manifest) {
        updateImportModeDescription(fileName, manifest);
        const modal = document.getElementById('import-mode-modal');
        if (modal) modal.style.display = 'flex';
    }
    function closeImportModeModal() {
        const modal = document.getElementById('import-mode-modal');
        if (modal) modal.style.display = 'none';
        pendingImportPayload = null;
        pendingImportManifest = null;
        pendingImportFileName = '';
        if (pendingImportInput) pendingImportInput.value = '';
        pendingImportInput = null;
    }
    async function executeImportPayload(data, manifest, mode) {
        const safeMode = mode === IMPORT_MODE_OVERWRITE ? IMPORT_MODE_OVERWRITE : IMPORT_MODE_COMPATIBLE;
        const importManifest = manifest || buildImportManifest(data);
        const selectedKeys = normalizeSelectedExportKeys(importManifest.selectedKeys);
        const localforageData = data.localforage && typeof data.localforage === 'object' ? data.localforage : {};
        if (safeMode === IMPORT_MODE_OVERWRITE && importManifest.isCompleteSelection) {
            await clearLocalforageKeysByCategories(selectedKeys);
            await clearDexieByCategories(selectedKeys);
        }
        for (const key of Object.keys(localforageData)) {
            await localforage.setItem(key, localforageData[key]);
        }
        const dbCatalog = Object.fromEntries(getExportDbCatalog().map(item => [item.key, item]));
        for (const dbKey of Object.keys(dbCatalog)) {
            const dbData = data[dbKey];
            if (!dbData || typeof dbData !== 'object') continue;
            const dbItem = dbCatalog[dbKey];
            for (const storeName of dbItem.stores) {
                if (!Object.prototype.hasOwnProperty.call(dbData, storeName)) continue;
                await restoreDexieStore(dbItem.instance[storeName], dbData[storeName], safeMode);
            }
        }
    }
    window.closeImportModeModal = closeImportModeModal;
    window.confirmImportMode = async function(mode) {
        if (!pendingImportPayload) return closeImportModeModal();
        const safeMode = mode === IMPORT_MODE_OVERWRITE ? IMPORT_MODE_OVERWRITE : IMPORT_MODE_COMPATIBLE;
        const compatibleBtn = document.getElementById('import-mode-compatible-btn');
        const overwriteBtn = document.getElementById('import-mode-overwrite-btn');
        const cancelBtn = document.getElementById('import-mode-cancel-btn');
        const originalCompatibleText = compatibleBtn ? compatibleBtn.innerText : '兼容导入';
        const originalOverwriteText = overwriteBtn ? overwriteBtn.innerText : '覆盖导入';
        if (compatibleBtn) {
            compatibleBtn.innerText = safeMode === IMPORT_MODE_COMPATIBLE ? '正在导入...' : originalCompatibleText;
            compatibleBtn.style.pointerEvents = 'none';
            compatibleBtn.style.opacity = '0.7';
        }
        if (overwriteBtn) {
            overwriteBtn.innerText = safeMode === IMPORT_MODE_OVERWRITE ? '正在导入...' : originalOverwriteText;
            overwriteBtn.style.pointerEvents = 'none';
            overwriteBtn.style.opacity = '0.7';
        }
        if (cancelBtn) {
            cancelBtn.style.pointerEvents = 'none';
            cancelBtn.style.opacity = '0.7';
        }
        try {
            await executeImportPayload(pendingImportPayload, pendingImportManifest, safeMode);
            alert('导入成功，即将刷新页面应用数据！');
            location.reload();
        } catch (err) {
            console.error(err);
            alert('导入失败：' + (err && err.message ? err.message : '文件格式可能不正确'));
        } finally {
            if (compatibleBtn) {
                compatibleBtn.innerText = originalCompatibleText;
                compatibleBtn.style.pointerEvents = 'auto';
                compatibleBtn.style.opacity = '1';
            }
            if (overwriteBtn) {
                overwriteBtn.innerText = originalOverwriteText;
                overwriteBtn.style.pointerEvents = 'auto';
                overwriteBtn.style.opacity = '1';
            }
            if (cancelBtn) {
                cancelBtn.style.pointerEvents = 'auto';
                cancelBtn.style.opacity = '1';
            }
        }
    };
    async function streamExportData(selectedKeys, btnElement) {
        try {
            const normalizedKeys = normalizeSelectedExportKeys(selectedKeys);
            if (!normalizedKeys.length) throw new Error('没有可导出的项目');
            const parts = [];
            let buffer = '{\n';
            let isFirstRootKey = true;
            function flushBuffer() {
                if (!buffer.length) return;
                parts.push(buffer);
                buffer = '';
            }
            function appendText(text) {
                buffer += text;
                if (buffer.length >= 1024 * 1024) {
                    flushBuffer();
                }
            }
            function openRootKey(key) {
                if (!isFirstRootKey) appendText(',\n');
                appendText(`  "${key}": `);
                isFirstRootKey = false;
            }
            openRootKey('meta');
            appendText(JSON.stringify({
                app: 'Mini Phone',
                schemaVersion: EXPORT_SCHEMA_VERSION,
                createdAt: new Date().toISOString(),
                selectedKeys: normalizedKeys
            }));
            if (normalizedKeys.some(key => ['settings', 'theme', 'contacts', 'voice', 'wallet', 'music'].includes(key))) {
                openRootKey('localforage');
                appendText('{\n');
                const localforageKeys = await localforage.keys();
                let isFirstLocalforageKey = true;
                for (const key of localforageKeys) {
                    if (!shouldExportLocalforageKey(normalizedKeys, key)) continue;
                    if (!isFirstLocalforageKey) appendText(',\n');
                    const value = await localforage.getItem(key);
                    appendText(`    ${JSON.stringify(key)}: ${JSON.stringify(value)}`);
                    isFirstLocalforageKey = false;
                }
                appendText('\n  }');
            }
            async function exportDexieStore(dbKey, dbInstance, storeNames) {
                openRootKey(dbKey);
                appendText('{\n');
                for (let storeIndex = 0; storeIndex < storeNames.length; storeIndex += 1) {
                    const storeName = storeNames[storeIndex];
                    appendText(`    ${JSON.stringify(storeName)}: [\n`);
                    const allItems = await dbInstance[storeName].toArray();
                    for (let rowIndex = 0; rowIndex < allItems.length; rowIndex += 1) {
                        if (rowIndex > 0) appendText(',\n');
                        appendText('      ' + JSON.stringify(allItems[rowIndex]));
                    }
                    appendText('\n    ]');
                    if (storeIndex < storeNames.length - 1) appendText(',\n');
                }
                appendText('\n  }');
            }
            const exportPlan = getExportPlanForKeys(normalizedKeys);
            for (const item of exportPlan) {
                await exportDexieStore(item.key, item.instance, item.stores);
            }
            appendText('\n}');
            flushBuffer();
            const blob = new Blob(parts, { type: 'application/json;charset=utf-8' });
            const didStartDownload = await downloadExportBlob(blob, getExportFileName());
            if (!didStartDownload && isIosLikeDevice()) {
                alert('已准备好导出文件，但当前浏览器取消了分享/下载。请重新点击导出并在弹出的系统面板里保存。');
            }
        } catch (err) {
            console.error("导出过程中发生错误:", err);
            alert("导出失败: " + err.message);
        }
    }
    async function exportAllData() {
        const btns = document.querySelectorAll('.btn-restore');
        let targetBtn = null;
        btns.forEach(b => { if (b.innerText === '导出数据') targetBtn = b; });
        if (targetBtn) {
            targetBtn.innerText = "正在流式打包，请耐心等待...";
            targetBtn.style.pointerEvents = "none";
            targetBtn.style.opacity = "0.7";
        }
        await new Promise(r => setTimeout(r, 50));
        // 全量导出所有的 key
        const allKeys = EXPORTABLE_DATA_KEYS.slice();
        await streamExportData(allKeys, targetBtn);
        if (targetBtn) {
            targetBtn.innerText = "导出数据";
            targetBtn.style.pointerEvents = "auto";
            targetBtn.style.opacity = "1";
        }
    }
    function _getBatchExportEnabledCheckboxes() {
        return Array.from(document.querySelectorAll('#export-checkbox-list input[type="checkbox"]:not(:disabled)'));
    }
    function updateBatchExportSelectAllButton() {
        const btn = document.getElementById('batch-export-select-all-btn');
        if (!btn) return;
        const checkboxes = _getBatchExportEnabledCheckboxes();
        const allChecked = checkboxes.length > 0 && checkboxes.every(cb => cb.checked);
        btn.innerText = allChecked ? '取消全选' : '全选';
    }
    function toggleBatchExportSelectAll() {
        const checkboxes = _getBatchExportEnabledCheckboxes();
        if (checkboxes.length === 0) return;
        const shouldCheckAll = checkboxes.some(cb => !cb.checked);
        checkboxes.forEach(cb => { cb.checked = shouldCheckAll; });
        updateBatchExportSelectAllButton();
    }
    function bindBatchExportCheckboxEvents() {
        const list = document.getElementById('export-checkbox-list');
        if (!list || list._batchExportBound) return;
        list._batchExportBound = true;
        list.addEventListener('change', function(e) {
            if (e.target && e.target.matches('input[type="checkbox"]:not(:disabled)')) {
                updateBatchExportSelectAllButton();
            }
        });
    }
    function openBatchExportModal() {
        bindBatchExportCheckboxEvents();
        updateBatchExportSelectAllButton();
        document.getElementById('batch-export-modal').style.display = 'flex';
    }
    function closeBatchExportModal() {
        document.getElementById('batch-export-modal').style.display = 'none';
    }
    async function executeBatchExport() {
        const checkboxes = document.querySelectorAll('#export-checkbox-list input[type="checkbox"]:checked:not(:disabled)');
        const selected = normalizeSelectedExportKeys(Array.from(checkboxes).map(cb => cb.value));
        if (selected.length === 0) return alert('请至少选择一项');
        const confirmBtn = document.querySelector('#batch-export-modal .action-buttons .btn-restore');
        const originalText = confirmBtn ? confirmBtn.innerText : '确认导出';
        if (confirmBtn) {
            confirmBtn.innerText = "正在流式打包，请耐心等待...";
            confirmBtn.style.pointerEvents = "none";
            confirmBtn.style.opacity = "0.7";
        }
        await new Promise(r => setTimeout(r, 50));
        await streamExportData(selected, confirmBtn);
        closeBatchExportModal();
        if (confirmBtn) {
            confirmBtn.innerText = originalText;
            confirmBtn.style.pointerEvents = "auto";
            confirmBtn.style.opacity = "1";
        }
    }
    window.toggleBatchExportSelectAll = toggleBatchExportSelectAll;
    async function importData(event) {
        const input = event && event.target;
        const file = input && input.files ? input.files[0] : null;
        if (!file) return;
        try {
            const rawText = await readImportFileText(file);
            const data = JSON.parse(rawText);
            pendingImportPayload = data;
            pendingImportInput = input || null;
            pendingImportFileName = file.name || '';
            pendingImportManifest = buildImportManifest(data);
            openImportModeModal(pendingImportFileName, pendingImportManifest);
        } catch (err) {
            console.error(err);
            alert('导入失败，文件格式可能不正确');
            if (input) input.value = '';
        }
    }
    async function resetAllData() {
        if (await window.showMiniConfirm('警告：此操作将永久清空所有设置、聊天记录、世界书等全部数据，且不可恢复！\n确定要继续吗？')) {
            if (await window.showMiniConfirm('最后一次确认，真的要清空所有数据吗？')) {
                try {
                    await localforage.clear();
                    await imgDb.delete();
                    await db.delete();
                    await maskDb.delete();
                    await contactDb.delete();
                    await emoDb.delete();
                    await chatListDb.delete();
                    await walletDb.delete();
                    alert('所有数据已清空，即将刷新页面！');
                    location.reload();
                } catch (e) {
                    console.error(e);
                    alert('重置失败: ' + e.message);
                }
            }
        }
                   }


